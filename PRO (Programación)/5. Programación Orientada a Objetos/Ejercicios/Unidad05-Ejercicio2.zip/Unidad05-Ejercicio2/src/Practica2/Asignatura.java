/*
 * 1.	Desarrollar una clase llamada Asignatura que:

 •	Tenga dos atributos prívate de tipo int (el  identificador) y de tipo double (la calificación).
 •	Tenga un constructor con un parámetro de tipo int.
 •	Tenga un getvalor para cada uno de los atributos.
 •	Tenga un setvalor para la calificación

 */
package Practica2;

// Asignatura
public class Asignatura {
//Atributos
    private int identificador;
    private double calificacion;

//Constructor
    public Asignatura(int param) {
        identificador = param;
    }

//Getvalores
    public int getIdentificador() {
        return identificador;
    }

    public double getCalificacion() {
        return calificacion;
    }

//Setvalores
    public void setCalificacion(double param) {
        calificacion = param;
    }
}
