/*
 * 3.	Desarrollar una clase llamada Profesor que:

 •	Tenga un método ponerNotas que recibe un parámetro de tipo Alumno y que no devuelve nada. 
 * Pondrá una calificación aleatoria a cada una de las asignaturas del alumno.
 •	Tenga un método calcularMedia que recibe un parámetro de tipo Alumno y devuelve un double.

 */
package Practica2;

///Profesor
public class Profesor {

    public void ponerNotas(Alumno param) {
        param.getAsigntaura1().setCalificacion(Math.random() * 10);
        param.getAsigntaura2().setCalificacion(Math.random() * 10);
        param.getAsigntaura3().setCalificacion(Math.random() * 10);
    }

    public double calcularMedia(Alumno param) {
        double nota1 = param.getAsigntaura1().getCalificacion();
        double nota2 = param.getAsigntaura2().getCalificacion();
        double nota3 = param.getAsigntaura3().getCalificacion();
        return (nota1 + nota2 + nota3) / 3;
    }
}
