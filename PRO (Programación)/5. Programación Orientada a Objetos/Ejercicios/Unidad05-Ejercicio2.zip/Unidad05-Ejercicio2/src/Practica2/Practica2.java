/*
 4.	Desarrollar una clase llamada Practica_2 que en su método main:

 •	Cree e inicialice tres Asignaturas
 •	Cree un Alumno con las tres Asignaturas.
 •	Cree un Profesor que le ponga calificaciones al Alumno y muestre por pantalla la media del Alumno.

 */
package Practica2;

//Práctica2
public class Practica2 {

    public static void main(String[] args) {
        Asignatura programacion = new Asignatura(1);
        Asignatura redes = new Asignatura(2);
        Asignatura estadistica = new Asignatura(3);

        Alumno antonio = new Alumno(programacion, redes, estadistica);

        Profesor pepe = new Profesor();

        pepe.ponerNotas(antonio);

        System.out.println("La media del alumno es: " + pepe.calcularMedia(antonio));
    }
}
