/*
 2.	Desarrollar una clase llamada Alumno que:

 •	Tenga tres atributos prívate de tipo Asignatura.
 •	Tenga un constructor con tres parámetros de tipo Asignatura que inicialice los tres atributos.
 •	Tenga un constructor con tres parámetros de tipo int que inicialice los tres atributos.
 •	Tenga un getvalor para cada uno de los atributos.


 */
package Practica2;

//Alumno
public class Alumno {
//Atributos
    private Asignatura asignatura1;
    private Asignatura asignatura2;
    private Asignatura asignatura3;

//Contructores
    public Alumno(Asignatura param1, Asignatura param2, Asignatura param3) {
        asignatura1 = param1;
        asignatura2 = param2;
        asignatura3 = param3;
    }

    public Alumno(int param1, int param2, int param3) {
        asignatura1 = new Asignatura(param1);
        asignatura2 = new Asignatura(param2);
        asignatura3 = new Asignatura(param3);
    }

//Getvalores
    public Asignatura getAsigntaura1() {
        return asignatura1;
    }

    public Asignatura getAsigntaura2() {
        return asignatura2;
    }

    public Asignatura getAsigntaura3() {
        return asignatura3;
    }
}
