/*
 7. Desarrollar una clase llamada Garaje que:
  Tendrá tres atributos, un coche, un String con la avería asociada y el número de coches que ha ido atendiendo.
  El garaje solo podrá atender a un coche en cada momento. Controlar esta premisa.
  Tenga un método aceptarCoche que recibe un parámetro de tipo Coche y la avería asociada. El garaje solo podrá atender a un coche en cada momento. Si ya está atendiendo uno, que devuelva un false.
  Tenga un método devolverCoche que dejará al garaje en estado de aceptar un nuevo coche.
 */
package Practica3;

public class Garaje {
    // Atributos

    private Coche coche = null;
    private String averia = null;
    private int numCochesAtendidos = 0;

    public int getNumCochesAtendidos() {
        return numCochesAtendidos;
    }

    public boolean aceptarCoche(Coche c, String a) {
        if (coche != null) //si tenemos uno, no aceptamos otro
        {
            return false;
        }
        coche = c;
        averia = a;
        if (averia.equals("aceite")) {
            coche.getMotor().setAceite(coche.getMotor().getAceite() + 10);
        }
        coche.acumularAveria(Math.random() * 1000);
        numCochesAtendidos++;
        return true;
    }

    public void devolverCoche() {

        coche = null;
        averia = null;
    }
}
