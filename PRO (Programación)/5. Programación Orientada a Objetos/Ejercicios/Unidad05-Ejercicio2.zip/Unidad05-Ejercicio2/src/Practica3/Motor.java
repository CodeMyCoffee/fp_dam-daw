/*
 5. Desarrollar una clase llamada Motor que:
  Tenga dos atributos prívate de tipo int (litros de aceite) y de tipo int (CV)
  Tenga un constructor con un parámetro de tipo int para los CV. Los litros de aceite por defecto serán 0.
  Tenga un getvalor para cada uno de los atributos.
  Tenga un setvalor para los litros.
 */
package Practica3;

public class Motor {
// Atributos

    private int aceite = 0;
    private int CV = 0;
// Constructor
    public Motor(int c) {
        CV = c;
    }
// Getvalores
    public int getAceite() {
        return aceite;
    }

    public int getCV() {
        return CV;
    }
// Setvalores
    public void setAceite(int a) {
        aceite = a;
    }
}
