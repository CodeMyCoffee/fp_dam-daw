/*

 */
package ELEMENTO;

public class EjecutaElemento {
    public static void main(String args[]){
         Elemento.numeroDeElementos();
        Elemento elemento=new Elemento("Hidrogeno");
        Elemento elemento2=new Elemento("Potasio");
        Elemento elemento3= new Elemento("Hierro");
        Elemento.numeroDeElementos();
    }
}
