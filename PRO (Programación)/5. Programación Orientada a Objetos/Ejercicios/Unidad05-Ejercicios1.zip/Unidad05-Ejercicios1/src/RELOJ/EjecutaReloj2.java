
package RELOJ;


public class EjecutaReloj2 {
    public static void main(String[] args) {
       
        Reloj hora3=new Reloj(12,12,12);
        hora3.imprimirReloj();
}
}
