/*
 * Implementa un Array de Alumnos
 */


import java.util.Scanner;

public class ArrayDeAlumnos {

    public static void main(String[] args) {
        String nombre;
        String apellido1, apellido2;
        int totAsig;
      
        Alumno[] curso = new Alumno[5]; //

        Scanner teclado = new Scanner(System.in);

        for (int i = 0; i < curso.length; i++) {
            System.out.println("Teclee el nombre del alumno");
            nombre = teclado.next();
            System.out.println("Teclee el 1er apellido del alumno");
            apellido1 = teclado.next();
            System.out.println("Teclee el 2do apellido del alumno");
            apellido2 = teclado.next();
            System.out.println("Teclee el número total de asignaturas en que se matricula");
            totAsig = teclado.nextInt();
            curso[i] = new Alumno(i, apellido1, apellido2, nombre, totAsig);
        }
        //asignar notas. Añado notas aleatorias entre 0 y 10
        for (int i = 0; i < curso.length; i++) {
            double[][] notasProvi = new double[2][curso[i].getNumAsignaturas()];

            for (int fila = 0; fila < notasProvi.length; fila++) {
                for (int columna = 0; columna < notasProvi[fila].length; columna++) {
                    notasProvi[fila][columna] = Math.random() * 10 + 0;
                }
            }
            curso[i].asignarNotas(notasProvi);
        }

        //Visualizacion
        for (int i = 0; i < curso.length; i++) {
            System.out.println(curso[i].toString());
            System.out.println(curso[i].pasaDeCurso());
        }
    }
}
