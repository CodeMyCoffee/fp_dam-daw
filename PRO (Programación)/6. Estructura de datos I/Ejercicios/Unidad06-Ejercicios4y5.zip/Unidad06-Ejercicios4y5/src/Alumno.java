
/*
 * 18. Dada la clase alumno
 */
public class Alumno { 

    private int númeroPersonal;
    private String apellido1, apellido2, nombre;
    private int numAsignaturas;
    private double[] notasFinales;
    private double notaMediaFinal;

    public Alumno(int numPer, String ap1, String ap2, String nom, int numAsig) {
        númeroPersonal = numPer;
        apellido1 = ap1;
        apellido2 = ap2;
        nombre = nom;
        numAsignaturas = numAsig;
        notasFinales = new double[numAsignaturas];
    }

    public Alumno(int numPer, String ap1, String ap2, String nom, int numAsig, double[] notasF, double nmf) {
        númeroPersonal = numPer;
        apellido1 = ap1;
        apellido2 = ap2;
        nombre = nom;
        numAsignaturas = numAsig;
        notasFinales = notasF;
        notaMediaFinal = nmf;
    }

    public String toString() {
        String resul;
        resul = "NP: " + númeroPersonal + "\n" + " Nombre: " + nombre
                + " Apellido1: " + apellido1
                + " Apellido2: " + apellido2 + "\n"
                + " Nota Media Final: " + notaMediaFinal ;
        return resul;
    }

    public double obtenerNotaMediaFinal() {
        return notaMediaFinal;
    }

    public int getNumAsignaturas() {
        return numAsignaturas;
    }

    /* Añade a la clase un método, de nombre asignarNotas, que reciba por parámetro 
     * una matriz de valores reales  con las notas que el alumno ha obtenido en dos 
     * evaluaciones realizadas. 
     * La primera dimensión de la matriz corresponderá  al número de evaluaciones y,
     * por tanto, sólo podrá contener 2 posiciones. 
     * La segunda dimensión corresponde a las calificaciones  obtenidas por el alumno
     * en cada una de las asignaturas. 
     * El método calculará la nota final para cada una de las asignaturas
     * teniendo en cuenta que la nota de la primera evaluación tiene un peso del 60%
     * y la de la segunda evaluación el 40% restante. 
     * El método también determinará la nota media final del alumno. 
     */
    public void asignarNotas(double[][] x) {
        //Compruebo que  las columnas de la matriz (asignaturas) es igual a numAsignaturas
        if (x[0].length == this.numAsignaturas && x[1].length == this.numAsignaturas) {
            //Compruebo que tiene 2 filas la matriz (2 evaluaciones)
            if (x.length == 2) {
                //Asigno al vector notasFinales la notaMedia de cada Asignatura
                for (int columna = 0; columna < this.numAsignaturas; columna++) {
                    this.notasFinales[columna] = (x[0][columna] * 0.6) + (x[1][columna] * 0.4);
                }

                //Recorro el vector NotasFinales y calculo la media
                for (int i = 0; i < this.notasFinales.length; i++) {
                    this.notaMediaFinal += this.notasFinales[i];
                }
                //Divido por el numero de Asignaturas para el calculo de la media
                this.notaMediaFinal /= this.numAsignaturas;

            } else {
                System.out.println("La matriz debe de tener 2 evaluaciones!!");
            }
        } else {
            System.out.println("La matriz debe tener " + this.numAsignaturas + " columnas");
        }
    }
    /* Añade a la clase un método, de nombre pasaDeCurso, que indique si el alumno podrá acceder al siguiente curso. 
     * Se considera que un alumno puede pasar de curso si su nota media final es mayor o igual de 5.0 y tiene menos de 3 
     * asignaturas suspensas. 
     */

    public boolean pasaDeCurso() {
        boolean aprobado = false;

        //Cuento las asignaturas suspendidas
        int suspensas = 0;

        for (int i = 0; i < this.notasFinales.length; i++) {
            if (this.notasFinales[i] < 5) {
                suspensas++;
            }
        }

        if (this.notaMediaFinal > 5 && suspensas < 3) {
            aprobado = true;
        }
        return aprobado;
    }

    public static void main(String[] args) {
        Alumno Pepe = new Alumno(0, "Martin", "Ferrer", "Pepe", 3);
        Alumno Maria = new Alumno(1, "Perez", "Mendoza", "Maria", 5);

        double[][] notasPepe = new double[2][Pepe.getNumAsignaturas()];
        //Añado notas aleatorias entre 0 y 10
        for (int fila = 0; fila < notasPepe.length; fila++) {
            for (int columna = 0; columna < notasPepe[fila].length; columna++) {
                notasPepe[fila][columna] = Math.random() * 10 + 0;
            }
        }

        double[][] notasMaria = new double[2][Maria.getNumAsignaturas()];
        //Añado notas aleatorias entre 0 y 10
        for (int fila = 0; fila < notasMaria.length; fila++) {
            for (int columna = 0; columna < notasMaria[fila].length; columna++) {
                notasMaria[fila][columna] = Math.random() * 10 + 0;
            }
        }

        Pepe.asignarNotas(notasPepe);
        Maria.asignarNotas(notasMaria);

        System.out.println(Pepe.toString());
        System.out.println("PEPE pasa de curso: " + Pepe.pasaDeCurso());
        System.out.println(Maria.toString());
        System.out.println("MARIA pasa de curso: " + Maria.pasaDeCurso());


    }
}
