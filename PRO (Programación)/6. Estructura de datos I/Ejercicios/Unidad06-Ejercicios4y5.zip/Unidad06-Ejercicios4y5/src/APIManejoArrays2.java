/*
 * 17. Escribe una clase, de nombre APIManejoArrays2, cuyo método main() implemente 
 * un programa que lleve a cabo las siguientes acciones:
 */


import java.util.Arrays;

public class APIManejoArrays2 {

    public static void main(String[] args) {
        String temp;
        /*
         * a) Declarar y construir un array de cadenas de objetos String de nombre arrStr 
         * que contenga las siguientes cadenas: “impresora”, “peto”, “mar”, “orilla” y “Orihuela”
         */
        String[] arrStr = {"impresora", "peto", "mar", "orilla", "Orihuela"};
        System.out.println("a) " + Arrays.toString(arrStr));
        /*
         * b) Ordenar el array arrStr alfabéticamente teniendo en cuenta que las letras 
         * mayúsculas figuran en el código Unicode antes que las minúsculas. Mostrar por 
         * pantalla el resultado de la ordenación.
         */
        Arrays.sort(arrStr);
        System.out.println("b) " + Arrays.toString(arrStr));
        /*
         * c) Ordenar el array arrStr alfabéticamente sin distinguir entre letras mayúsculas 
         * y minúsculas. Mostrar por pantalla el resultado de la ordenación.
         */
        Arrays.sort(arrStr, String.CASE_INSENSITIVE_ORDER);
        System.out.println("c) " + Arrays.toString(arrStr));
    }
}
