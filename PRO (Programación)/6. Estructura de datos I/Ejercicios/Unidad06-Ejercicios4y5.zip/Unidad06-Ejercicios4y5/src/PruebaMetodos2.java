/*
 * Escribe una clase de nombre PruebaMetodos2 con los métodos estáticos que se 
 * proponen a continuación. Incluir en el método main() de la clase las sentencias 
 * necesarias para comprobar el correcto funcionamiento de dichos métodos.
 */
import java.util.Arrays;

public class PruebaMetodos2 {

    public static void main(String[] args) {

        int[][] m = new int[5][5];
        //Ej10
        System.out.println("Ej10\tEfectuado");
        rellenarMatrizSecuencia2D(m);
        //Ej11
        System.out.println("\nEj11\n");
        mostrarMatrizID(m);
        //Ej12
        System.out.println("\nEj12\n");
        System.out.println(matrizIntComoString(m));
        //Ej13
        System.out.println("\nEj13\n");
        System.out.println("la suma es: " + obtenerSumaElementosMatriz(m));
        //Ej14
        System.out.println("Ej14\n");
        rellenarMatrizAsteriscos(7);
        //Ej15
        System.out.println("\nEj15\n");
        int[][] laterales = obtenerLaterales(m);
        for (int[] fila : laterales) {
            for (int valor : fila) {
                System.out.print(valor + "\t");
            }
            System.out.println();
        }

    }

    //ARRAYS MULTIDIMENSIONALES//
    //Ej10 - Escribe un método, de nombre rellenarMatrizSecuencia2D, 
    //que reciba una matriz de enteros por parámetro y la rellene para que sus 
    //posiciones almacenen un valor que se irá incrementando en una unidad por columnas. 
    //La matriz se rellenará de manera que dos elementos consecutivos según la primera 
    //dimensión almacenen dos valores también consecutivos. Una matriz de 5 elementos 
    //en la primera dimensión y 5 en la segunda quedaría como sigue:
    //      0 5 10 15 20
    //      1 6 11 16 21
    //      2 7 12 17 22
    //      3 8 13 18 23
    //      4 9 14 19 24
    public static int[][] rellenarMatrizSecuencia2D(int[][] m) {
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[i].length; j++) {
                m[i][j] = i + j * m.length;
            }
        }
        return m;
    }

    //Ej11 - Escribe un método, de nombre mostrarMatrizID, que reciba por parámetro 
    //un array bidimensional (matriz) de enteros y muestre sus elementos por pantalla 
    //de forma que la primera dimensión de la matriz se corresponda con las filas y la 
    //segunda con las columnas.
    public static void mostrarMatrizID(int[][] m) {
        for (int[] fila : m) {
            for (int num : fila) {
                System.out.print(num + "\t");
            }
            System.out.println();
        }
    }

    //Ej12 - Escribe un método, de nombre matrizIntComoString, que reciba por parámetro 
    //un array bidimensional (matriz) de enteros y devuelva una cadena con la representación 
    //textual de la matriz recibida. La cadena dispondrá los elementos de la matriz de 
    //forma que la primera dimensión se corresponda con las filas y la segunda con las columnas.
    public static String matrizIntComoString(int[][] m) {
        String matriz = "";
        for (int[] m1 : m) {
            matriz = matriz + Arrays.toString(m1) + "\n";
        }
        return matriz;
    }

    //Ej13 - Escribe un método, de nombre obtenerSumaElementosMatriz, que reciba por 
    //parámetro un array bidimensional de números enteros y devuelva la suma de 
    //todos sus elementos
    public static int obtenerSumaElementosMatriz(int[][] m) {
        int suma = 0;
        for (int[] fila : m) {
            for (int valor : fila) {
                suma = suma + valor;
            }
        }
        return suma;
    }

    //Ej14 - Escribe un método, de nombre rellenarMatrizAsteriscos, que reciba por
    //parámetro un valor entero que especificará el número de filas de asteriscos 
    //que albergará la matriz. La primera fila contendrá un solo asterisco situado 
    //en la posición central según la segunda dimensión de la matriz. Cada nueva 
    //fila contendrá dos asteriscos más y también se encontrarán centrados según 
    //la segunda dimensión de la matriz. El aspecto final que debe presentar la 
    //matriz si se recibe un número de filas de asteriscos sería el siguiente:
    //    
    //            *
    //          * * * 
    //        * * * * *
    //      * * * * * * *
    //    * * * * * * * * *
    public static void rellenarMatrizAsteriscos(int n) {
        char[][] piram = new char[n][(n * 2) - 1];
        for (int i = 0; i < piram.length; i++) {
            for (int j = 0; j < ((i * 2) + 1); j++) {
                piram[i][((piram[i].length / 2) - i) + j] = '*';
            }
        }

        for (char[] fila : piram) {
            for (char valor : fila) {
                System.out.print(valor);
            }
            System.out.println();
        }
    }

    //Ej15 - Escribe un método, de nombre obtenerLaterales, que reciba por parámetro 
    //una matriz de valores enteros y devuelva una matriz con los valores de los 
    //cuatro laterales -superior, izquierdo, derecho e inferior-, de la matriz recibida
    public static int[][] obtenerLaterales(int[][] m) {
        int[][] n = new int[2][2];
        n[0][0] = m[0][0];
        n[0][1] = m[0][m[0].length - 1];
        n[1][0] = m[m.length - 1][0];
        n[1][1] = m[m.length - 1][m[m.length - 1].length - 1];
        return n;
    }

    //Ej15 AMPLIACIÓN. Devuelve la primera fila, la primera column, la última columna y la última fila
    public static int[][] obtenerLateralesCompletos(int[][] m) {
        int[][] n = new int[4][];
        n[0] = new int[m[0].length];  //calcular longitud primera fila
        n[1] = new int[m.length];  //calcular longitud primera columna
        n[2] = new int[m.length]; //calcular longitud ultima columna
        n[3] = new int[m[m.length - 1].length]; //calcular longitud ultima fila

        //o bien  System.arraycopy(m[0], 0, n[0], 0, m[0].length);
        for (int i = 0; i < m[0].length; i++) {
            n[0][i] = m[0][i];
        }
        for (int i = 0; i < m.length; i++) {
            n[1][i] = m[i][0];
            n[2][i] = m[i][m[0].length - 1];
        }
        // o bien System.arraycopy(m[m.length - 1], 0, n[3], 0, m[m.length - 1].length);
        for (int i = 0; i < m[m.length - 1].length; i++) {
            n[3][i] = m[m.length - 1][i];
        }
        return n;
    }

}
