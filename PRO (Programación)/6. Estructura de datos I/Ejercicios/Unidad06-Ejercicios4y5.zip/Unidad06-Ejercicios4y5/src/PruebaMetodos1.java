/*
 * Escribe una clase de nombre PruebaMetodos1 con los métodos estáticos que se 
 * proponen a continuación. Incluir en el método main() de la clase las sentencias
 * necesarias para comprobar el correcto funcionamiento de dichos métodos
 * 
 */


import java.util.Arrays;

public class PruebaMetodos1 {

    //ARRAYS UNIIMENSIONALES//
    //Ej01 - Escribe un método, de nombre mostrarArrayPantalla2, que reciba por parámetro 
    //un array de enteros y muestre sus valores por pantalla separados por comas.
    public static void mostrarArrayPantalla2(int[] m) {
        String mostrar = "";
        for (int i = 0; i < m.length; i++) {
            if (i != (m.length) - 1) {
                mostrar = mostrar + m[i] + " , ";
            } else {
                mostrar = mostrar + m[i];
            }
        }
        System.out.println(mostrar);
        //Seria equivalente a   System.out.println(Arrays.toString(m));
    }

    //Ej02 - Escribe un método, de nombre obtenerArrayComoString, que reciba un array 
    //de enteros por parámetro y devuelva una cadena de caracteres con su contenido.
    public static String obtenerArrayComoString(int[] m) {
        String mostrar = "";
        for (int i = 0; i < m.length; i++) {
            if (i != (m.length) - 1) {
                mostrar = mostrar + m[i] + " , ";
            } else {
                mostrar = mostrar + m[i];
            }
        }
        return mostrar;
        //seria equivalente a return m.toString();  
    }

    //Ej03 - Escribe un método, de nombre completarArray3, que reciba un array de enteros 
    //por parámetro y lo rellene de forma que contenga tantos números pares, 
    //a partir del cero, como permita su capacidad.
    public static int[] completarArray3(int[] m) {
        int n = 0;
        for (int i = 0; i < m.length; i++) {
            m[i] = n;
            n = n + 2;
        }
        return m;
    }

    //Ej04 - Escribe un método, de nombre obtenerSumaArray, que reciba por parámetro 
    // un array de enteros y devuelva la suma de sus elementos.
    public static int obtenerSumaArray(int[] m) {
        int suma = 0;
        for (int i = 0; i < m.length; i++) {
            suma = suma + m[i];
        }
        return suma;
    }

    //Ej05 - Escribe un método, de nombre arrayPotencias2, que cree un array y lo 
    // rellene con potencias de 2. Las potencias de 2 comenzarán en 2º y el número 
    // total de ellas se recibirá por parámetro. El método devolverá el array creado.
    public static int[] arrayPotencias2(int n) {
        int j = 0;
        int[] m = new int[n];
        for (int i = 0; i < m.length; i++) {
            m[i] = (int) Math.pow(2, j);
            j++;
        }
        return m;
    }

    //Ej06 - Escribe un método que reciba como parámetro un array de cadenas y devuelva 
    // la cadena resultante de concatenar todas las contenidas en el array.
    public static String obtenerConcatArray(String[] m) {
        String concat = "";
        for (int i = 0; i < m.length; i++) {
            concat = concat + " " + m[i];
        }
        return concat;
    }

    //Ej07 - Escribe un método, de nombre obtenerSumaLongCadArray, que reciba por 
    // parámetro un array de cadenas y devuelva el número total de caracteres de 
    // todas las cadenas del array.
    public static int obtenerSumaLongCadArray(String[] m) {
        int log = 0;
        for (int i = 0; i < m.length; i++) {
            log = log + m[i].length();
        }
        return log;
    }

    //Ej08 - Escribe un método, de nombre obtenerLongCadenas, que reciba por parámetro 
    // un array de cadenas y devuelva un array de enteros con los tamaños de las 
    // cadenas contenidas en el array.
    public static int[] obtenerLongCadenas(String[] m) {
        int[] cadenas = new int[m.length];
        for (int i = 0; i < m.length; i++) {
            cadenas[i] = m[i].length();
        }
        return cadenas;
    }

    //Ej09 - Escribe un método, de nombre obtenerArrCad5Vocales, que reciba por parámetro
    // un array de cadenas y devuelva un array con las que contengan las 5 vocales. 
    // Para la consideración de un carácter como vocal no se tendrá en cuenta si 
    // está en mayúsculas o minúsculas.
    public static String[] obtenerArrCad5Vocales(String[] m) {
        int contador = 0, j = 0;
        for (int i = 0; i < m.length; i++) {
            if (m[i].contains("a") && m[i].contains("e") && m[i].contains("i") && m[i].contains("o") && m[i].contains("u")) {
                contador++;
            }
        }
        String[] cadenas = new String[contador];
        for (int i = 0; i < m.length; i++) {
            if (m[i].contains("a") && m[i].contains("e") && m[i].contains("i") && m[i].contains("o") && m[i].contains("u")) {
                cadenas[j] = m[i];
                j++;
            }
        }
        return cadenas;
    }

    //Ej10 - (AMPLIACION) Escribe un método, de nombre obtenerArrayOrdAlfab, que reciba por parámetro 
    // un array de cadenas de caracteres y las ordene alfabéticamente. 
    // La ordenación no se verá afectada por la expresión de los caracteres expresados 
    // en mayúsculas o minúsculas. Es decir, las cadenas “ALBACETE”, “antonio”, y “BURGOS” 
    // quedarán ordenadas en este mismo orden
    public static void obtenerArrayOrdAlfab(String[] cad) {
        //Metodo 1
        //ALGORITMO SELECCIÓN DIRECTA
        String aux;
        for (int j = 0; j < cad.length; j++) {
            for (int k = j + 1; k < cad.length; k++) {
                if (cad[k].compareToIgnoreCase(cad[j]) < 0) {
                    aux = cad[j];
                    cad[j] = cad[k];
                    cad[k] = aux;
                }
            }
        }

        //Metodo 2

        //Arrays.sort(cad, String.CASE_INSENSITIVE_ORDER); 
    }

    //MAIN//
    public static void main(String[] args) {

        int x = 5, y = 7;
        int[] m = {1, 34, 2, 35, 6, 73, 8, 9, 12, 13, 14};
        String[] n = new String[4];
        n[0] = "marcos";
        n[1] = "clara";
        n[2] = "pola";
        n[3] = "nic";
        String[] l = {"aeiou", "buho", "murcielago", "cartulina"};
        String[] s = {"valencia", "IRLANDA", "segorbe", "MADRID", "barcelona", "salamanca"};

        //Ej01
        System.out.print("Ej01\t");
        mostrarArrayPantalla2(m);
        //Ej02
        System.out.print("\nEj02\t");
        System.out.println(obtenerArrayComoString(m));
        //Ej03
        System.out.print("\nEj03\t");
        completarArray3(m);
        System.out.println(obtenerArrayComoString(m));
        //Ej04
        System.out.print("\nEj04\t");
        obtenerSumaArray(m);
        System.out.println(obtenerSumaArray(m));
        //Ej05
        System.out.print("\nEj05\t");
        System.out.println(obtenerArrayComoString(arrayPotencias2(y)));
        //Ej06
        System.out.print("\nEj06\t");
        System.out.println(obtenerConcatArray(n));
        //Ej07
        System.out.print("\nEj07\t");
        System.out.println(obtenerSumaLongCadArray(n));
        //Ej08
        System.out.print("\nEj08\t");
        obtenerLongCadenas(n);
        for (int i = 0; i < n.length; i++) {
            System.out.print(obtenerLongCadenas(n)[i] + "\n\t");
        }
        //Ej09
        System.out.print("\nEj09\t");
        obtenerArrCad5Vocales(l);
        for (int i = 0; i < obtenerArrCad5Vocales(l).length; i++) {
            System.out.print(obtenerArrCad5Vocales(l)[i] + "\n\t");
        }
        //Ej10
        System.out.print("\nEj10\t");
        obtenerArrayOrdAlfab(s);
        for (int i = 0; i < s.length; i++) {
            System.out.print(s[i] + "\n\t");
        }
        System.out.println();
    }
}
