package Strings01;

import java.util.Scanner;

public class Ejercicio01 {

    public static void main(String[] args) {
        String nombre, apellido1, apellido2, completo;
        char ultimo, primer, primerMay;
        int veces, i;
        Scanner lector = new Scanner(System.in);
        System.out.print("Nombre: ");
        nombre = lector.nextLine();
        System.out.print("Primer Apellido: ");
        apellido1 = lector.nextLine();
        System.out.print("segundo Apellido: ");
        apellido2 = lector.nextLine();
        completo = nombre + " " + apellido1 + " " + apellido2;
        //el nombre completo con todos los caracteres en minúsculas y luego en mayúsculas y su longitud
        System.out.println("El nombre completo : " + completo);
        System.out.println("El nombre completo en mayusculas : " + completo.toUpperCase());
        System.out.println("El nombre completo en minusculas : " + completo.toLowerCase());
        System.out.println("consta de " + completo.length() + " caracteres");
        //los dos primeros caracteres de la cadena (solo en el caso de que la longitud de esta sea de dos o más caracteres)
        //los dos últimos caracteres de la cadena (solo en el caso de que la longitud de esta sea de dos o más caracteres)
        if (completo.length() > 1) {
            System.out.println("Los dos primeros caracteres: " + completo.substring(0, 2));
            System.out.println("Los dos últimos caracteres: " + completo.substring(completo.length() - 2));
        }
        //el número de ocurrencias en la cadena del último carácter
        ultimo = completo.charAt(completo.length() - 1);
        veces = 0;
        i = 0;
        while (i != -1) {
            i = completo.indexOf(ultimo, i);
            if (i != -1) {
                veces++;
                i++;
            }
        }
        System.out.println("El último caracter es " + ultimo + " y se repite " + veces + " veces");
        //la cadena con todas las ocurrencias del primer carácter en mayúsculas
        primer = completo.charAt(0);
        primerMay = Character.toUpperCase(primer);
        System.out.println("Reemplazo el primer caracter " + primer + " por " + primerMay + " : " + completo.replace(primer, primerMay));

        //version sin modificar la cadena original. 
                //Eso si, puedo reasignar: completo="***"+completo+"***";
        //la cadena con tres asteriscos por delante y por detrás  
        System.out.println("Con tres asteriscos por delante y por detrás  : " + "***" + completo + "***");
        //version sin modificar la cadena original
        //la cadena invertida
        System.out.print("El nombre invertido : ");
        for (i = completo.length() - 1; i >= 0; i--) {
            System.out.print(completo.charAt(i));
        }
        System.out.println();
        //version  modificando la cadena original StringBuilder
        StringBuilder completoMod = new StringBuilder(completo);
        //la cadena con tres asteriscos por delante y por detrás 
        completoMod.insert(0, "***");
        completoMod.append("***");
        System.out.println("Con tres asteriscos por delante y por detrás  : " + completoMod);
        //la cadena invertida
        completoMod.reverse();
        System.out.println("El nombre invertido : " + completoMod);
        completoMod.delete(0, 3);
        completoMod.delete(completoMod.length() - 3, completoMod.length());
        System.out.println("El nombre invertido sin los asteriscos: " + completoMod);


    }
}
