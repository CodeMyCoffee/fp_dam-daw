package Strings01;

public class Ejercicios02030405 {
    //Escribe un método que, dado un String, devuelve otro objeto String 
    //en el que se cambian todas las vocales minúsculas del original por la letra 'a'.

    public static String cambiaVocales(String s) {
        s = s.replace('e', 'a');
        s = s.replace('i', 'a');
        s = s.replace('o', 'a');
        s = s.replace('u', 'a');
        return s;
    }
//Escribe un método que, dada una cadena de caracteres, 
//devuelve la mitad inicial de la cadena

    public static String mitadCadena(String s) {
        return s.substring(0, s.length() / 2);
    }
//Escribe un método que, dada una cadena de caracteres, 
//sustituya todas las ocurrencias del texto “es” por “no por”

    public static String cambiaEs(String s) {
        return s.replaceAll("es", "no por");
    }
//Escribe un segundo método que sustituya 
//todos los grupos de dígitos por un único carácter asterisco

    public static String cambiaDigitos(String s) {
        return s.replaceAll("\\d+", "*");
    }
//Escribe un método que, dada una cadena de caracteres, 
//cuente cuántas veces aparece la misma en dicho texto

    public static int cuentaVeces(String s, String busca) {
        int i = 0, veces = 0;
        while (i != -1) {
            i = s.indexOf(busca, i);
            if (i != -1) {
                veces++;
                i += busca.length();
            }
        }
        return veces;
    }

    public static void main(String[] args) {
        String cadena = "123... Veamos si esto funciona... 123 probando";
        System.out.println("Cadena inicial : " + cadena);
        System.out.println("Cadena cambiando vocales por a  : " + cambiaVocales(cadena));
        System.out.println("Cadena partida por la mitad  : " + mitadCadena(cadena));
        System.out.println("Cadena cambiando 'es' por 'no por'  : " + cambiaEs(cadena));
        System.out.println("Cadena cambiando vocales por a  : " + cambiaDigitos(cadena));
        System.out.println("Cuantas veces aparece la subcadena '123'  : " + cuentaVeces(cadena, "123"));
        System.out.println("Cuantas veces aparece la subcadena 'n'  : " + cuentaVeces(cadena, "n"));
    }
}
