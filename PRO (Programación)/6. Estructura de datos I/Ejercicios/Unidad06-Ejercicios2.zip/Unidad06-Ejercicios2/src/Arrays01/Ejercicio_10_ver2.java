package Arrays01;
// Versión de David Gimeno

import java.util.Random;


public class Ejercicio_10_ver2 {
      public static void main (String[] args){
        Random aleatorio = new Random();
        int[] vector = new int[20];
        int contador = 0;
        
        // Inicialización del vector
    System.out.println("Inicializamos el vector");
    for (int i = 0; i < vector.length; i++){
        vector[i] = aleatorio.nextInt(100);
        System.out.print (" ( "+i+" ) "+vector[i]+"  ");
    }
    System.out.println();
        //Igualdad de vectores
    for (int i = 0; i < vector.length; i++){
        for (int j = 0; j != i && j < vector.length; j++){
            if (vector[i] == vector[j]){
                System.out.println("v("+i+") = v("+j+") = "+vector[i]);
                contador = contador + 1;
            }
        }
    }
    if(contador == 0){
        System.out.println("No existen vectores iguales");
    }
}
}
