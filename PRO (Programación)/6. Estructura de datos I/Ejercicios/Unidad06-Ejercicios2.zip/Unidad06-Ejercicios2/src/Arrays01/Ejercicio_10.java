package Arrays01;

/*
 10. Escribe un programa que permita introducir un vector de veinte elementos, 
 * visualizar e indicar luego si hay o no algún elemento repetido. 
 * En ese caso indicar cuáles son y la posición que ocupan.
 * Versión de ******* MIGUEL ÁNGEL MENDOZA ********");
 */

public class Ejercicio_10 {

    public static void main(String[] args) {

        int[] vector = new int[20];
        int[] posicion = new int[20];//vector utilizo para guardar posiciones de números repetidos

        for (int i = 0; i < vector.length; i++) { //Bucle crear vector números aleatorios
            vector[i] = (int) (Math.random() * 25 + 0);
        }

        System.out.println("**************************************");
        for (int i = 0; i < vector.length; i++) { // Bucle para imprimir en pantalla el vector
            System.out.println("Número[" + i + "]: " + vector[i]);
        }
        System.out.println("****************************************");
        int contador = 0, pos = 0;
        boolean noEstaRepetido = false;//variable boolena para que no salgan el mismo número mostrado varias veces por pantalla
        for (int i = 0; i < vector.length; i++) { // Bucle para imprimir en pantalla el vector
            contador = 0;//reinicio el contador en cada pasada del bucle j, por eso if con j=0
            pos = 0;
            noEstaRepetido = false;// 
            for (int j = 0; j < vector.length; j++) { // Bucle para imprimir en pantalla el vector

                if (vector[i] == vector[j]) { // Si son iguales incrementamos contador
                    contador++;
                    posicion[pos] = j;
                    pos++;
                }
            }
            if (contador > 1) {
                for (int h = 0; h < i; h++) { //Bucle que comprueba si ese numero a estado repetido anteriormente y pone noEstaRepetido en TRUE
                    if (vector[i] == vector[h]) {
                        noEstaRepetido = true;
                    }
                }

                if (noEstaRepetido == false) { //Si el número repetido no ha sido mostrado por pantalla anteriormente lo muestro por pantalla
                    System.out.println("El número: " + vector[i] + " está repetido: " + contador + " veces.");
                    System.out.print("Posición: ");
                    for (int k = 0; k < contador; k++) {
                        System.out.print("[" + posicion[k] + "]");
                    }
                    System.out.println("\n****************************************");
                }
            }

        }
    }
}
