package Arrays01;

/*
6.Escribe un programa que permita introducir vector de diez elementos numéricos, 
* visualizarlo y luego indicar cuales elementos son pares y ocupan una posición par, 
* indicar contenido y posición.
Repetir para contenido múltiplo de tres y posición impar.
 */

public class Ejercicio_06 {

    public static void main(String[] args) {
        int[] numero = new int[10];

        for (int i = 0; i < numero.length; i++) { //Bucle pedir números
            numero[i] = (int) (Math.random() * 1500 + 0);
        }
        int suma = 0;
        System.out.println("NÚMEROS Y POSICIONES:");
        System.out.println("******** PAR ********");
        for (int i = 0; i < numero.length; i++) { //Bucle para mostrar  por pantalla
            if (i % 2 == 0 && numero[i] % 2 == 0) {
                System.out.println("Posición[" + i + "]: " + numero[i]);
            }
        }
        System.out.println("******** IMPAR ********");
        for (int i = 0; i < numero.length; i++) { //Bucle para mostrar  por pantalla
            if (i % 2 != 0 && numero[i] % 2 != 0) {
                System.out.println("Posición[" + i + "]: " + numero[i]);
            }
        }
        System.out.println("******** MÚLTIPLO DE 3 ********");
        for (int i = 0; i < numero.length; i++) { //Bucle para mostrar  por pantalLA
            if (i % 3 == 0 && numero[i] % 3 == 0) {
                System.out.println("Posición[" + i + "]: " + numero[i]);
            }
        }
    }
}
