package Arrays01;

/*
14. Escribe un programa que permita, a partir de un vector V de 50 elementos, 
* crear e imprimir un vector P con los elementos de V cuyo contenido sea par.
* Si no lo hubiera visualizar el mensaje adecuado.
 */

public class Ejercicio_14 {

    public static void main(String[] args) {
        int[] V = new int[50];
        int contador = 0;

        for (int i = 0; i < V.length; i++) { //Bucle crear vector números aleatorios
            V[i] = (int) (Math.random() * 25 + 0);
            if (V[i] % 2 == 0) { // Para saber el tamaño del vector P cuento primero cuantos pares
                contador++;
            }
        }
        System.out.println("**************************************");
        System.out.println("*************** VECTOR V *************");
        System.out.println("***************************************");
        for (int i = 0; i < V.length; i++) { // Visualizo por pantalla V
            System.out.println("Número[" + i + "]: " + V[i]);
        }
        int[] P = new int[contador];//Creo vector P con tamaño del número de pares
        int posicionV = 0;//Variable para incrementar en uno cada vez que haya un num par
        for (int i = 0; i < V.length; i++) { 
            if (V[i] % 2 == 0) { // Si son pares asigno el valor
                P[posicionV] = V[i];
                posicionV++;
            }
        }
        System.out.println("**************************************");
        System.out.println("*************** VECTOR P *************");
        System.out.println("***************************************");
        if (contador == 0) { // IF para indicar mensaje si no hay números pares
            System.out.println("NO HAY NIGÚN NÚMERO PAR EN EL VECTOR");
        } else {
            for (int i = 0; i < P.length; i++) { // Imprimo pantalla vector P
                System.out.println("Número[" + i + "]: " + P[i]);
            }
        }
    }
}
