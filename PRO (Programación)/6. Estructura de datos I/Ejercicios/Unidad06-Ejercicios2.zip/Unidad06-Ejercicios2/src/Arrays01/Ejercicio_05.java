package Arrays01;

/*
Escribe un programa que permita leer una secuencia de 50 números, 
* guardarlos en un vector. Calcular e imprimir la suma de aquellos 
* cuyo contenido sea par.
 */

public class Ejercicio_05 {

    public static void main(String[] args) {
        int[] numero = new int[50];

        for (int i = 0; i < numero.length; i++) { //Bucle pedir números
            numero[i] = (int) (Math.random() * 1500 + 0);
        }
        int suma = 0;
        for (int i = 0; i < numero.length; i++) { //Bucle para mostrar  por pantalla
            System.out.println("Número[" + i + "]: " + numero[i]);
            if (numero[i] % 2 == 0) {
                suma = suma + numero[i];
            }
        }
        System.out.println("------------------------");
        System.out.println("SUMA de los contenidos pares: \t" + suma);

    }
}
