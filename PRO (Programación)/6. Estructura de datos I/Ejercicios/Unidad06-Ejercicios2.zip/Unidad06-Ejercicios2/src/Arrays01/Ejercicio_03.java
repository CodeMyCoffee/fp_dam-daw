package Arrays01;
/* 3.Escribe un programa que permita introducir un
* vector de 20 elementos numéricos y visualizarlos de cuatro en cuatro. 
 */

public class Ejercicio_03 {

    public static void main(String[] args) {
        int[] numero = new int[20];
        for (int i = 0; i < numero.length; i++) { //Bucle pedir números
            numero[i] = (int) (Math.random() * 25 + 0);
        }
        System.out.println("****Mostrar en grupos de 4**********************");

        for (int i = 0; i < numero.length; i++) { //Bucle para mostrar  por pantalla
            System.out.printf(" %4d " , numero[i]);
            if ((i+1)%4==0)
                System.out.println();    

        }

    }
}
