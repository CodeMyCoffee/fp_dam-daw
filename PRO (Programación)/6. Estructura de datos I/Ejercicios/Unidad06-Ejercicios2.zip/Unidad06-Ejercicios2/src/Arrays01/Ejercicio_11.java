package Arrays01;

/*
11. Escribe un programa que permita introducir un vector P de diez elementos
* numéricos, visualizar su contenido, crear un vector V con los elementos de P 
* que sean mayores de diez. Visualizar luego el contenido de V.
 */

public class Ejercicio_11 {

    public static void main(String[] args) {
        int[] P = new int[10];
        int contador = 0;

        for (int i = 0; i < P.length; i++) { //Bucle crear vector números aleatorios
            P[i] = (int) (Math.random() * 25 + 0);
            if (P[i] > 10) { // Para saber el tamaño del vector V cuento primero cuantos hay mayor que 10
                contador++;
            }
        }
        System.out.println("**************************************");
        System.out.println("*************** VECTOR P *************");
        System.out.println("***************************************");
        for (int i = 0; i < P.length; i++) { // Visualizo por pantalla P
            System.out.println("Número[" + i + "]: " + P[i]);
        }
        int[] V = new int[contador];//Creo vector V con tamaño del número de elementos >10
        int posicionV = 0;//Variable para incrementar en uno cada vez que haya un num>10
        for (int i = 0; i < P.length; i++) { //Bucle 
            if (P[i] > 10) { // Si el valor es > 10 entonces se lo asigno al vector V
                V[posicionV] = P[i];
                posicionV++;
            }
        }
        System.out.println("**************************************");
        System.out.println("*************** VECTOR V *************");
        System.out.println("***************************************");
        for (int i = 0; i < V.length; i++) { // Imprimo pantalla vector V
            System.out.println("Número[" + i + "]: " + V[i]);
        }
    }
}
