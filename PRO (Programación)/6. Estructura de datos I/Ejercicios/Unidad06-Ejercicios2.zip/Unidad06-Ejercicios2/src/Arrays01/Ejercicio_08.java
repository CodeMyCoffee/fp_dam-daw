package Arrays01;

/*
Escribe un programa que permita introducir vector de veinte elementos y visualizar, 
* indicar luego posición y contenido de todos aquellos que sean mayores que diez. 
* Indicando cuantos elementos hay que cumplen esta condición 
 */
public class Ejercicio_08 {

    public static void main(String[] args) {
        int[] numero = new int[20];

        for (int i = 0; i < numero.length; i++) { //Bucle crear vector
            numero[i] = (int) (Math.random() * 25 + 0);
        }


        for (int i = 0; i < numero.length; i++) {
            System.out.println("Número[" + i + "]: " + numero[i]);
        }
        System.out.println("*************> 10************");
        int contador = 0;
        for (int i = 0; i < numero.length; i++) {
            if (numero[i] > 10) {
                System.out.println("Número[" + i + "]: " + numero[i]);
                contador++;
            }
        }
        System.out.println("*****************************");
        System.out.println("Número de elementos mayores de 10: " + contador);
    }
}
