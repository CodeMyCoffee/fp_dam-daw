package Arrays01;

/*
1. Escribe un programa que permita introducir los valores de un vector 
* de diez elementos numéricos y luego imprimirlos.
 */

public class Ejercicio_01 {

    public static void main(String[] args) {
        int[] numeros = new int[10];

        for (int i = 0; i < numeros.length; i++) { //Bucle números aleatorios
           numeros[i] = (int) (Math.random() * 25 + 0);
        }
        System.out.println("************************************");

        for (int i = 0; i < numeros.length; i++) { //Bucle para mostrar  por pantalla
            System.out.println("Número " + (i+1) + ": " + numeros[i]);
        }


    }
}
