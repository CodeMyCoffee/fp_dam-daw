package Arrays01;

/*
Escribe un programa que permita introducir un vector de 50 elementos 
* numéricos e indique luego cual es el primer elemento cuyo contenido 
* sea cero. Si no lo hubiera, debe indicarlo.
 */

public class Ejercicio_07 {

    public static void main(String[] args) {
        int[] numero = new int[50];

        for (int i = 0; i < numero.length; i++) { //Bucle crear vector 
            numero[i] = (int) (Math.random() * 9 + 0);
        }
        
        for (int i = 0; i < numero.length; i++) { //Bucle para mostrar  por pantalla
                System.out.println("Posición[" + i + "]: " + numero[i]);
        }
        System.out.println("**************************");
        boolean esCero = false;

        for (int i = 0; i < numero.length; i++) {
            if (numero[i] == 0 && esCero == false) {
                System.out.println("Posicion[" + i + "]: " + numero[i]);
                esCero = true;
            }
        }
        if (esCero == false) {
            System.out.println("No hay ningún cero");
        }

    }
}
