package Arrays01;

/*Escribe un programa que permita introducir un vector de diez elementos alfanuméricos
y luego visualizar los que ocupen la posición par. 
Repetir para los de posición impar. 
 */
import java.util.Scanner;

public class Ejercicio_02 {

    public static void main(String[] args) {
        String[] elemento = new String[10];
        Scanner lector = new Scanner(System.in);
        for (int i = 0; i < elemento.length; i++) { //Bucle pedir números
            System.out.print("Elemento " + (i+1) + ": ");
   
           elemento[i] = lector.nextLine();
        }
        System.out.println("*******POSICIÓN PAR********");

        for (int i = 0; i < elemento.length; i++) { //Bucle para mostrar  por pantalla
            if ((i+1) % 2 == 0) {
                System.out.println("Elemento " + (i+1) + ": " + elemento[i]);
            }
        }

        System.out.println("*******POSICIÓN IMPAR********");

        for (int i = 0; i < elemento.length; i++) { //Bucle para mostrar  por pantalla
            if ((i+1) % 2 != 0) {
                System.out.println("Elemento " + (i+1) + ": " + elemento[i]);
            }
        }

    }
}
