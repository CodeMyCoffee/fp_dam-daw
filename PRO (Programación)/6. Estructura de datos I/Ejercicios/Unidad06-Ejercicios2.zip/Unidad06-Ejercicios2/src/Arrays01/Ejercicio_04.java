package Arrays01;

/*
Escribe un programa que permita introducir vector numérico de diez elementos,
* visualizarlo y luego visualizar los elementos cuyo contenido sea par, 
* indicando su posición.Repetir para impar.
 */

public class Ejercicio_04 {

    public static void main(String[] args) {
        int[] numero = new int[10];

        for (int i = 0; i < numero.length; i++) { //Bucle pedir números
            numero[i] = (int) (Math.random() * 1500 + 0);
        }
        System.out.println("**************************");
        for (int i = 0; i < numero.length; i++) { //Bucle para mostrar  por pantalla
            System.out.println("Número[" + i + "]: " + numero[i]);
        }
        System.out.println("********NÚMERO PAR********");
        for (int i = 0; i < numero.length; i++) { //Bucle para mostrar  por pantalla
            if (numero[i] % 2 == 0) {
                System.out.println("Posición[" + i + "]: " + numero[i]);
            }
        }
        System.out.println("********NÚMERO IMPAR********");
        for (int i = 0; i < numero.length; i++) { //Bucle para mostrar  por pantalla
            if (numero[i] % 2 != 0) {
                System.out.println("Posición[" + i + "]: " + numero[i]);
            }
        }
    }
}
