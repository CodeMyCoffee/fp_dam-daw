///Un programa que calcula una divisió i una suma.
public class DivideYSuma {
 public static void main(String[] args) {
double dividend = 20.0;
double divisor = 6.0;
double sumarAlFinal = 3.0;
System.out.println((dividend/divisor) + sumarAlFinal);
}
}
