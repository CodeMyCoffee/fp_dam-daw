/*
 * Dias de Vida
 * 
 */

/**
 *
 * @author DAM
 */
public class DiasDeVida {
    public static void main(String[] args){
        int edad=23;
        int dias=edad*360;
        System.out.println("No diré a nadie que tienes "+dias+"  dias!");
    }
    }
            
