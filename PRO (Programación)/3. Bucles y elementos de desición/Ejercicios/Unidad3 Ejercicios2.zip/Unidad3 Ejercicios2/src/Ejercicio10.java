
import java.util.Scanner;

/*
 *10.- Hacer un programa que lea tres números A,B,C y los imprima ordenados
 */
public class Ejercicio10 {

    public static void main(String[] args) {
        int mayor, menor, intermedio;
        int a, b, c;
        Scanner tec = new Scanner(System.in);
        System.out.println("Por favor, introduzca un número entero: ");
        a = tec.nextInt();
        System.out.println("Por favor, introduzca otro  número entero: ");
        b = tec.nextInt();
        System.out.println("Por favor, introduzca otro  número entero: ");
        c = tec.nextInt();
        if (a < b) {
            menor = a;
            intermedio = b;
        } else {
            menor = b;
            intermedio = a;
        }
        if (c < menor) {
            mayor = intermedio;
            intermedio = menor;
            menor = c;
        } else {
            mayor = c;
        }
        if (mayor < intermedio) {
            mayor = intermedio;
            intermedio = c;
        }
        System.out.printf("Ordenados:  %d < %d < %d \n", menor, intermedio, mayor);
    }
}
