/*
 2.- Introducir reiteradamente un número A.
  Si A es mayor que 100 calcular el cuadrado de A.
  Si A es menor o igual que 100 calcular la mitad de A.
  Si A es igual a cero finalizar el programa.

 */

import java.util.*;

public class Ejercicio02 {

    public static void main(String[] args) {
        Scanner tec = new Scanner(System.in);
       double num, resultado;
        do {
            System.out.println("Por favor, introduzca un número: ");
            num = tec.nextDouble();
            if (num != 0) {
                if (num > 100) {
                    resultado =  Math.pow(num, 2);
                    System.out.println("El cuadrado de " + num + " es " + resultado);
                } else {
                    resultado = num / 2;
                    System.out.println("La mitad de " + num + " es " + resultado);
                }

            }
        } while (num != 0);
    }
}
