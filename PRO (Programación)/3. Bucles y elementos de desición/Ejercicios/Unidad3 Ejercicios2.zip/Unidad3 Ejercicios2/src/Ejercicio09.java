/*
9.- Imprimir los números perfectos menores de 1.000.
Un número se considera perfecto cuando la suma de sus divisores, excepto el mismo, es igual al propio número.
 */


public class Ejercicio09 {
    public static void main(String[] args) {
        System.out.println("Los numeros perfectos son: ");
        for (int num=1;num<1000;num++){
            int suma=0;
            for (int divisor=1;divisor<num;divisor++){
                if (num%divisor==0){
                    suma = suma + divisor;
                }
            }
            if(num==suma)
                System.out.println(num);
        }
    }
}
