/*
6.- Introducir un número y calcular el factorial de ese número.
 */
import java.util.*;
/**
 *
 * @author Alejandro Raez Campos
 */
public class Ejercicio06 {
    public static void main(String[] args) {
        Scanner tec = new Scanner(System.in);
        int num;
        int i=1;
        long suma=1;
       
        System.out.println("Por favor, introduzca un número entero: ");
        num = tec.nextInt();
        do{
           
            suma = suma * i;
            if(i<num){
                System.out.print(i+" x ");
            }else
                System.out.print(i);
             i++;
            
        }while(i<=num);
        System.out.println( " = "+suma);
    }
}
