/*
 3.-Calcular e imprimir 

 4+7+10+...+28
 ---------------
 6*9*12*...*27
 */

public class Ejercicio03 {

    public static void main(String[] args) {

        long producto = 1;
        int suma = 0;
        for (int numerador = 4; numerador <= 28; numerador += 3) {
            suma = suma + numerador;
        }
        for (int denominador = 6; denominador <= 27; denominador += 3) {
            producto = producto * denominador;
        }
        System.out.println(suma + "/" + producto + " = " + (double) suma / producto);
    }
}
