
import java.util.Scanner;

/*
 * 8.- Introducir  un  número  A  y  un  número  B  que  sea  mayor  que  A,  buscar  e 
 imprimir todos los números entre A y B que sean primos
 */
public class Ejercicio08 {

    public static void main(String[] args) {
        int mayor, menor;
        int a, b;
        Scanner tec = new Scanner(System.in);
        System.out.println("Por favor, introduzca un número entero: ");
        a = tec.nextInt();
        System.out.println("Por favor, introduzca otro  número entero: ");
        b = tec.nextInt();
        menor = a < b ? a : b;
        mayor = a < b ? b : a;
        System.out.println("Numeros primos del " + menor + " al " + mayor + " : ");
        for (int numero = menor; numero <= mayor; numero++) {
            boolean primo = true;
            int divisor = 2;
            while (divisor < numero && primo) {
                if (numero % divisor == 0) {
                    primo = false;
                }
                divisor++;
            }
            if (primo) {
                System.out.println(numero);
            }
        }
    }
}
