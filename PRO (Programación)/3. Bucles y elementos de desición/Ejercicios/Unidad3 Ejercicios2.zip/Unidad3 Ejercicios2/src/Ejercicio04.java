/*
 4.- Calcular y visualizar, los números y la suma de los números n comprendidos entre 100 y 1000 que cumplen que
 n * (n+1) / 5 = múltiplo de 5.
 */

public class Ejercicio04 {

    public static void main(String[] args) {

        int suma = 0;
        for (int n = 100; n <= 1000; n++) {
            if ((n * (n + 1) / 5) % 5 == 0) {
                System.out.print(n + " ");
                suma = suma + n;
            }
        }
        System.out.println("\nLa suma de los números que cumplen la condicion es: " + suma);

    }
}
