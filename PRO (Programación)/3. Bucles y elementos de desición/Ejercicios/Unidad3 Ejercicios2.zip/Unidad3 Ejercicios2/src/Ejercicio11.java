/*
11.- Queremos crear un programa que imprima el triangulo de Floyd para un numero introducido por el usuario.
Para el número 5 el triángulo es:
1
1 2
1 2 3
1 2 3 4
1 2 3 4 5
 */
import java.util.*;

public class Ejercicio11 {
    public static void main(String[] args) {
        Scanner tec = new Scanner(System.in);
        int num;
        System.out.println("Por favor, introduzca un número: ");
        num = tec.nextInt();
        
        for(int fila=1;fila<=num;fila++){
            for(int columna=1;columna<=fila;columna++){
                System.out.print(columna+" ");
            }
            System.out.println();
        }
    }
}
