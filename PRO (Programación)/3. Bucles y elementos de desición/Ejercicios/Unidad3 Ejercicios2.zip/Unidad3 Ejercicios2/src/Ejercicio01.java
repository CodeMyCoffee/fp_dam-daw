/*
1. Queremos crear un programa que escriba la serie ,5,7,10,12,15,17,....,1800
(Observa que se obtiene +2,+3,+2,+3, ...... )
 */


public class Ejercicio01 {
    public static void main(String[] args) {
        int num = 5;
        boolean sumo2 = true;
        while (num<=1800){
            System.out.print(num+" ");
            if(sumo2)
                num+=2;
            else 
                num+=3;
            sumo2 = !sumo2;
        }
        System.out.println();
    }
}
