/*
 5.- Introducir los valores A,B,C.
  Si A/C es mayor que 30 calcular e imprimir (A / C) * B^3
  Si A/C es menor o igual que 30 calcular e imprimir 2^2 + 4^2 +...+ 30^2
 */

import java.util.*;

public class Ejercicio05 {

    public static void main(String[] args) {
        Scanner tec = new Scanner(System.in);
        int supuesto1 = 0, supuesto2 = 0;
        int suma = 0, cuadrado;
        System.out.println("Por favor, introduzca un número entero: ");
        int a = tec.nextInt();
        System.out.println("Por favor, introduzca otro número entero: ");
        int b = tec.nextInt();
        System.out.println("Por favor, introduzca otro número entero: ");
        int c = tec.nextInt();

        if ((a / c) > 30) {
            supuesto1 = (a / c) * (int) Math.pow(b, 3);
        } else {
            suma=0;
            for (int i = 2; i <= 30; i += 2) {
                cuadrado =i*i;
                suma = suma + cuadrado;
                if (i <30) {
                    System.out.print(cuadrado+" + ");
                } else {
                    System.out.print( cuadrado);
                }
            }
            System.out.println(" = " + suma);

        }

    }
}
