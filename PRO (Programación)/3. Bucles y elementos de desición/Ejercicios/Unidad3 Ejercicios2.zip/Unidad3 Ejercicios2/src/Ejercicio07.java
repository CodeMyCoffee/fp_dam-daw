/*
 7.- Introducir un número. Mostrar el factorial de los números comprendidos entre 1 y ese número.
 */

import java.util.*;


public class Ejercicio07 {

    public static void main(String[] args) {
        Scanner tec = new Scanner(System.in);
        int num;
              long  producto = 1;
        System.out.println("Por favor, introduzca un número entero: ");
        num = tec.nextInt();
        for (int n = 1; n <= num; n++) {
            for (int fact = 1; fact <= n; fact++) {
                if (fact < n) {
                    System.out.print(fact + " x ");
                } else {
                    producto = producto * fact;  
                    System.out.print(fact + " = " + producto);
                }
            }
            System.out.println();
        }
    }

}
