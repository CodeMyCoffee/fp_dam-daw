/*
 Introducir A y B que sea mayor que A. Visualizar los números de A hasta B
 e indicar cuantos hay que sean pares.
 */

import java.util.Scanner;

public class EjercicioBUCLES04 {

    public static void main(String args[]) {
        int a, b;
        int contpares = 0;

        Scanner lector = new Scanner(System.in);
        System.out.print("Introduce A: ");
        a = lector.nextInt();

        System.out.print("Introduce B(MAYOR QUE A): ");
        b = lector.nextInt();

        if (b > a) { //Para comprobar que b sea mayor que a
            while (b >= a) {
                System.out.println(a);
                a++;
                if (a % 2 == 0) {
                    contpares++;
                }
            }
            System.out.println("Numeros pares: " + contpares);
        } else { //Si b no es mayor que a mensaje por pantalla.
            System.out.println("B tiene que ser mayor que A");
        }
    }
}
