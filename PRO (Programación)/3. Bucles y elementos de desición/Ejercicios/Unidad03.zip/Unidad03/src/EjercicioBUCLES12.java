/*
 11. Escribe un programa que permita determinar la probabilidad con que
 aparece cada uno de los valores al lanzar un dado. Para ello se lanzará el
 dado 1.000.000 de veces y se visualizará cuántas veces a aparecido cada
 número y el porcentaje que representa respecto al total.
 */

import java.util.Scanner;

public class EjercicioBUCLES12 {

    public static void main(String args[]) {
        int uno = 0, dos = 0, tres = 0, cuatro = 0, cinco = 0, seis = 0, dado;
        int lanzamientos=1000000;
        for (int i = 1; i <= lanzamientos; i++) {
            dado = (int) (Math.random() * 6 + 1); //Math.random()*Valorlimite+valorinicial
            if (dado == 1) {
                uno++;
            }
            if (dado == 2) {
                dos++;
            }
            if (dado == 3) {
                tres++;
            }
            if (dado == 4) {
                cuatro++;
            }
            if (dado == 5) {
                cinco++;
            }
            if (dado == 6) {
                seis++;
            }
        }//Cierre for

        System.out.println("Número de unos: " + uno + " \t\tPorcentaje: " + (float) uno / lanzamientos*100 + " %"); //Divido entre 10000 porque es dividir entre 1000000 y multiplicar por 100
        System.out.println("Número de doses: " + dos + " \tPorcentaje: " + (float)dos / lanzamientos*100 + " %");
        System.out.println("Número de treses: " + tres + " \tPorcentaje: " + (float)tres / lanzamientos*100 + " %");
        System.out.println("Número de cuatros: " + cuatro + " \tPorcentaje: " +(float) cuatro / lanzamientos*100 + " %");
        System.out.println("Número de cincos: " + cinco + " \tPorcentaje: " + (float)cinco / lanzamientos*100 + " %");
        System.out.println("Número de seises: " + seis + " \tPorcentaje: " + (float)seis /lanzamientos*100 + " %");

    }
}
