/*
 6.Visualizar la tabla de multiplicar del uno al diez.
 */

public class EjercicioBUCLES06 {

    public static void main(String args[]) {
        int producto;
        for (int i = 1; i <= 10; i++) { //Primer bucle tabla del número del 1 al 10
            for (int j = 0; j <= 10; j++) { //Segundo bucle tabla multiplicado por j
                producto = i * j;
                System.out.println(i + " x " + j + " = " + producto);
            }
            System.out.println("");
        }
    }
}
