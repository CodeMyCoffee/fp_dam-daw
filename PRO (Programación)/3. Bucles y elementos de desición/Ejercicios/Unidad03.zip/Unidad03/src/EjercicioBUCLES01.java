/*
1. Mostrar los números 48, 50, 52, 54,……...., 100.
 */

public class EjercicioBUCLES01 {
    public static void main(String args[]){
        for (int i = 48; i <= 100; i+=2){
        System.out.println(i);
        }
    }
}
