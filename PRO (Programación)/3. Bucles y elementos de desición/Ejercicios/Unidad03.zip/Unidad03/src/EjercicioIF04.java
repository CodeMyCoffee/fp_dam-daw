/* Escribe un programa que solicite dos números reales y los escriba
 * ordenados de menor a mayor
 */

import java.util.Scanner;

public class EjercicioIF04 {

    public static void main(String args[]) {
        int num1;
        int num2;
        //Se declara el objeto lector de la clase Scanner
        Scanner lector = new Scanner(System.in);
        System.out.print("Dime un numero: ");
        //Se lee un valor 
        num1 = lector.nextInt();

        System.out.print("Dime otro numero: ");
        //Se lee un valor y se espera a que el usuario pulse intro
        num2 = lector.nextInt();

        if (num1 > num2) {
            System.out.println("Ordenados de menor a mayor: " + num2 + " y " + num1);
        } else if (num1 < num2) {
            System.out.println("Ordenados de menor a mayor: " + num1 + " y " + num2);
        } else {
            System.out.println("Los numeros: " + num2 + " y " + num1 + " son iguales");
        }

    }
}
