/*
 5. Visualizar los números de 1 a 100 e indicar al final: Cuantos hay pares y su
suma. Cuantos hay impares y su suma. Cuantos hay que sean múltiplos de
cuatro y de siete y su suma.
 */


public class EjercicioBUCLES05 {
    public static void main(String args[]){
        int pares=0,sumapares=0,impares=0,sumaimpares=0,multcuatro=0,sumamultcuatro=0,multsiete=0,sumamultsiete=0;
        
        
        for (int i = 1; i <= 100; i++){
          if(i%2 == 0){  //PARES
            pares++;
            sumapares=sumapares+i;
            }
           if(i%2 != 0){  //IMPARES
            impares++;
            sumaimpares=sumaimpares+i;
            }
           if(i%4 == 0){  //MULTIPLOS DE 4
            multcuatro++;
            sumamultcuatro=sumamultcuatro+i;
            }
            if(i%7 == 0){  //MULTIPLOS DE 7
            multsiete++;
            sumamultsiete=sumamultsiete+i;
            }
        }//CIERRE FOR
        //Mostramos por pantalla los resultados
        System.out.println("Número de pares: "+pares);
        System.out.println("Número de impares: "+impares);
        System.out.println("Número de múltiplos de 4: "+multcuatro);
        System.out.println("Número de múltiplos de 7: "+multsiete);
        System.out.println("Suma de pares: "+sumapares);
        System.out.println("Suma de impares: "+sumaimpares);
        System.out.println("Suma de multiplos de 4: "+sumamultcuatro);
        System.out.println("Suma de multiplos de 7: "+sumamultsiete);
        
    }
}
