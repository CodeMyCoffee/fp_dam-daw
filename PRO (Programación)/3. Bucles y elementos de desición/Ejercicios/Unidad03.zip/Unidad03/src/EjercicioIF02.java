/* Escribe un programa que solicite la edad de una persona y muestre un
 * mensaje por pantalla que indique si es mayor o menor que 25
 */

import java.util.Scanner;

public class EjercicioIF02 {

    public static void main(String args[]) {
        int edad;
        //Se declara el objeto lector de la clase Scanner
        Scanner lector = new Scanner(System.in);
        System.out.print("Dime tu edad: ");
        //Se lee un valor 
        edad = lector.nextInt();
        if (edad > 25) {
            System.out.println("Tienes más años, concretamente: " + edad + " años");
        } else if (edad == 25) {
            System.out.println("Tu edad es 25 años");
        } else {
            System.out.println("Tienes menos de 25 años, concretamente: " + edad + " años");
        }

    }
}