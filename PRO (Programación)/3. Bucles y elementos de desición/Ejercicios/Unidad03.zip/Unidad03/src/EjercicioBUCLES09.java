/*
Escribe un programa que solicite al usuario un número entero positivo. El
programa debe presentar en pantalla la descomposición en factores primos
de dicho número.
Por ejemplo, si el número es 28 debe escribir 36=2 *2 * 3 * 3.
 */

import java.util.Scanner;

public class EjercicioBUCLES09 {
   public static void main(String args[]){
                 
      int num,i=2,flag=0;
        Scanner read = new Scanner(System.in);
        
        System.out.print("Introduce un numero entero positivo: ");
        num = read.nextInt();
        
        if(num>0)
        {
            System.out.print( num + " = ");
            do
            {
                if(num%i==0)
                {
                    num=num/i;
                    if(flag==0)//Si es = 0, es la primera vez que se ejecuta y no quiero que salga el *
                    {
                        System.out.print(i);
                        flag=1;
                    }
                    else
                        System.out.print("*" + i); //Sino ya le doy el formato * + num  
                }
                else
                    i++;
            }while(num!=1);
            System.out.println("");
        }// Cierre if numero >0
        else
            System.out.println("ERROR!!"); //Si el numero introducido es menor que       
       }
}
        
        