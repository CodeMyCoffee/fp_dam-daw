/* Escriba un programa en el que se solicite un número entero al usuario y el
 * programa escribirá un mensaje por pantalla que indique si se trata de un
 * número par o de un número impar
 */

import java.util.Scanner;

public class EjercicioIF03 {

    public static void main(String args[]) {
        int numero;
        //Se declara el objeto lector de la clase Scanner
        Scanner lector = new Scanner(System.in);
        System.out.print("Dime un numero: ");
        //Se lee un valor 
        numero = lector.nextInt();

        if (numero % 2 == 0) {
            System.out.println("El número: " + numero + " es un numero par");
        } else {
            System.out.println("El número: " + numero + " es impar");
        }

    }
}
