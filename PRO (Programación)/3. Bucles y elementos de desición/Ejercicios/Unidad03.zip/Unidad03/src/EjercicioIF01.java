/* Escribe un programa que solicite la edad de una persona y muestre un
 * mensaje por pantalla indicando si es mayor de edad o no
 */

import java.util.Scanner;

public class EjercicioIF01 {

    public static void main(String args[]) {
        int edad;
        //Se declara el objeto lector de la clase Scanner
        Scanner lector = new Scanner(System.in);
        System.out.print("Dime tu edad: ");
        //Se lee un valor 
        edad = lector.nextInt();
        if (edad >= 18) {
            System.out.println("Eres mayor de edad");
        } else {
            System.out.println("NO eres mayor de edad");
        }
    }
}
