
/*
 9. Escribe un programa para calcular la edad de una persona solicitando la
 fecha actual y la fecha de su nacimiento.
 */

import java.util.GregorianCalendar;
import java.util.Scanner;

public class EjercicioIF08 {

    public static void main(String args[]) {
        int diaAc, mesAc, añoAc, diaNa, mesNa, añoNa, edad;

        Scanner lector = new Scanner(System.in);
        //tomo la fecha actual del sistema. podría preguntarla
        GregorianCalendar fecha = new GregorianCalendar();
      
        diaAc = fecha.get(GregorianCalendar.DAY_OF_MONTH);
        mesAc = fecha.get(GregorianCalendar.MONTH) + 1;
        añoAc = fecha.get(GregorianCalendar.YEAR);
        

        System.out.print("Día nacimiento: ");
        diaNa = lector.nextInt();
        System.out.print("Mes nacimiento: ");
        mesNa = lector.nextInt();
        System.out.print("Año nacimiento: ");
        añoNa = lector.nextInt();

        edad = añoAc - añoNa;
        if (añoNa < añoAc)//Comprobar que el año actual sea mayor que el año de nacimiento
        {
            if (mesAc < mesNa)//Si el mes actual es menor al de nacimiento un año menos,porque no los ha cumplido aun
            {
                edad--;
            }
            if (mesAc == mesNa && diaAc < diaNa)//Si es el mismo mes de nacimiento pero no ha llegado el dia se le resta un año
            {
                edad--;
            }
            if (mesNa == mesAc && diaNa == diaAc)//Si la fecha de nacimiento (mes y dia) es igual a la actual feliz cumpleaños
            {
                System.out.println("FELIZ CUMPLEAÑOS");
            }
            System.out.println("Tu edas es: " + edad);
        } else {
            System.out.println("No has nacido todavía");
        }

    }
}
