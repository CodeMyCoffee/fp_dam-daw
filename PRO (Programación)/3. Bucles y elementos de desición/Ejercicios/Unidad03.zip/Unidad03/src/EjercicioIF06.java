/*
 6.Escribe un programa que solicite un valor real que indica una cantidad de
 dinero en centimos. El programa debe mostrar por pantalla la mínima cantidad
 de monedas de cada tipo en que se debe devolver la cantidad de dinero
 indicada.
 */

import java.util.Scanner;

public class EjercicioIF06 {

    public static void main(String args[]) {

        float dineroFloat;
        int euros, centimos;
        int billete50, billete20, billete10, billete5;
        int moneda2 , moneda1 , moneda50c , moneda20c , moneda10c ,
                moneda5c , moneda2c, moneda1c;
        Scanner lector = new Scanner(System.in);

        System.out.print("Introduce el dinero en €: ");
        dineroFloat = lector.nextFloat();
        if (dineroFloat > 0) {
        euros = (int) dineroFloat; 
        // centimos= (int) ( (dineroFloat-euros)*100); pierdo algun centimo
        centimos= Math.round((dineroFloat-euros)*100);
        
            System.out.println(centimos);
            //ojo, falta billetes de 500, de 200 y de  100
            //billete de 50€
            billete50 = euros / 50;
            euros = euros % 50;
            //billete de 20€
            billete20 = euros / 20;
            euros = euros % 20;
            //billete de 10€
            billete10 = euros / 10;
            euros = euros % 10;
            //billete de 5€
            billete5 = euros / 5;
            euros = euros % 5;
            //monedas de 2€
            moneda2 = euros / 2;
            euros = euros % 2;
            //monedas de 1€
            moneda1 = euros ;
                    
            //monedas de 0.5€
            moneda50c = centimos / 50;
            centimos = centimos % 50;
            //monedas de 0.2€
            moneda20c = centimos / 20;
            centimos = centimos % 20;
            //monedas de 0.10€
            moneda10c = centimos / 10;
            centimos = centimos % 10;
            //monedas de 0.05€
            moneda5c = centimos / 5;
            centimos = centimos % 5;
            //monedas de 0.02€
            moneda2c = centimos / 2;
            centimos = centimos % 2;
            //monedas de 0.01€
            moneda1c = centimos ;

            System.out.println("billete de 50€: " + billete50);
            System.out.println("billete de 20€: " + billete20);
            System.out.println("billete de 10€: " + billete10);
            System.out.println("billete de 5€: " + billete5);

            System.out.println("Monedas de 2€: " + moneda2);
            System.out.println("Monedas de 1€: " + moneda1);
            System.out.println("Monedas de 50 centimos de €: " + moneda50c);
            System.out.println("Monedas de 20 centimos de €: " + moneda20c);
            System.out.println("Monedas de 10 centimos de €: " + moneda10c);
            System.out.println("Monedas de 5 centimos de €: " + moneda5c);
            System.out.println("Monedas de 2 centimos de €: " + moneda2c);
            System.out.println("Monedas de 1 centimo de €: " + moneda1c);
        } else {
            System.out.print("ERROR!! La cantidad de dinero debe ser un número positivo.");
        }



    }
}
