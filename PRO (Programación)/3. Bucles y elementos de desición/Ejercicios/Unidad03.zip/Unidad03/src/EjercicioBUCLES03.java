/*
 3. Mostrar los impares de 1 a 99 indicando al final cuantos son. Repetir para
 los pares y para los múltiplos de cinco.
 */

public class EjercicioBUCLES03 {

    public static void main(String args[]) {
        int contimpares = 0, contpares = 0, contmult5 = 0;

        //IMPARES
        for (int i = 1; i <= 99; i++) {
            if (i % 2 != 0) {  //Si no es divisible por 2 es impar
                System.out.println(i);
                contimpares++;
            }
        }
        System.out.println("El numero de impares es: " + contimpares);

        //PARES
        for (int i = 1; i <= 99; i++) {
            if (i % 2 == 0) {  //Si no es divisible por 2 es impar
                System.out.println(i);
                contpares++;
            }
        }
        System.out.println("El numero de pares es: " + contpares);

        //MULTIPLOS DE 5
        for (int i = 1; i <= 99; i++) {
            if (i % 5 == 0) {  //Si no es divisible por 2 es impar
                System.out.println(i);
                contmult5++;
            }
        }
        System.out.println("El numero de múltiplos de 5 es: " + contmult5);


    }
}
