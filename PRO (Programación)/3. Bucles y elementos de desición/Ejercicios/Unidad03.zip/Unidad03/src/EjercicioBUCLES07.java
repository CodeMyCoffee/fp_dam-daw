/*
 Escribe un programa que calcule la potencia de un número real (a) elevado
 a un número entero (b). Tenga en cuenta que tanto a como b pueden valer
 0 o pueden ser números negativos.
 */

import java.util.Scanner;

public class EjercicioBUCLES07 {

    public static void main(String args[]) {
        double base, acumulador = 1;
        int exponente, i;

        Scanner lector = new Scanner(System.in);
        System.out.print("Dime la base: ");
        base = lector.nextDouble();
        System.out.print("Dime el exponente: ");
        exponente = lector.nextInt();

        System.out.println(base + " elevado a " + exponente + " es: " +Math.pow(base, exponente));
    
        if (base == 0 && exponente == 0) {
            System.out.println("Indeterminado");
        } else {
            //Si el exponente es mayor que 0
            if (exponente >= 0) {
                for (i = 1; i <= exponente; i++) {
                    acumulador = acumulador * base;
                }
            } //Exponentes negativos
            else {
                
                for (i = 1; i <= -(exponente); i++) {  // ó Math.abs(exponente)
                    acumulador = acumulador *  base;
                }//fin del for.
                acumulador=1/acumulador;
            }
            //Se controlan los casos cuando 0^a cualquier cosa es 0 y a^0 es siempre 1
            System.out.println(base + " elevado a " + exponente + " es: " + acumulador);
        }

    }
}
