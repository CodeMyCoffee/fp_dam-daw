/*
 7. Escribe un programa que calcule la cuota que se debe abonar en el club de
 golf. La cuota es de 500 €. Tendrán un 50% de descuento las personas
 mayores de 65 años y un 25% los menores de 18 años si los padres no son
 socios y 35% si los padres son socios.
 */
import java.util.Scanner;

public class EjercicioIF07conChar {

    public static void main(String arg[]) {

        int cuota = 500, edad;
        char padresSocios;
        String respuesta;

        Scanner lector = new Scanner(System.in);
        System.out.print("Dime tu edad: ");
        edad = lector.nextInt();

        if (edad >= 65) {
            cuota = cuota - (cuota * 50 / 100);
        } else if (edad < 18) {
            System.out.print("¿Tus padres son socios? (S/N) :");
            lector.nextLine(); //limpio el buffer
            respuesta=lector.nextLine(); //leo un String
            respuesta=respuesta.toUpperCase(); //lo paso a mayusculas
            padresSocios = respuesta.charAt(0); //me quedo con el primer caracter
            /*Atención!
            *para comparar Strings no puedo usar ==, escribiria
            if (respuesta.equalsIgnoreCase("SI"){...}
            */        
            if (padresSocios=='S' ) { 
                cuota = cuota - (cuota * 35 / 100);
            } else {
                cuota = cuota - (cuota * 25 / 100);
            }
        }
        System.out.println("Debes pagar la siguiente cuota: " + cuota);
    }
}
