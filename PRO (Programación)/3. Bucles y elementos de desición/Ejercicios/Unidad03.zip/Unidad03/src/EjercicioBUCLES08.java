/*
 7. Escribe un programa que solicite un número estero e indique si se trata de
 un número primo o no.
 */

import java.util.Scanner;

public class EjercicioBUCLES08 {

    public static void main(String args[]) {
        int num, contador = 0;

        Scanner lector = new Scanner(System.in);
        System.out.print("Introduce un número entero: ");
        num = lector.nextInt();
        //Comprobamos la definición:
        //Un número es primo si y solo si es dibisuble por la unidad y por si mismo
        //En esta versión hacemos muchos cáculos innecesarios
        for (int i = 1; i <= num; i++) { //Segundo bucle tabla multiplicado por j
            if (num % i == 0) {
                contador++; //Contador que contara cuantas veces es ese número divisible
            }//Cierre if
        }//Cierre for

        System.out.println(contador);
        if (contador > 2) //Si contador mayor o igual que 2 no es primo ya que un numero primo solo es divisible por el y por uno
        {
            System.out.println(num + " NO es un número primo");
        } else {
            System.out.println(num + " SI es un número primo");
        }

    }
}
