/*
 Escribe un programa que solicite tres valores enteros con el día, mes y año
 de una fecha e indique si se trata de valores válidos para una fecha.
 */
import java.util.Scanner;

public class EjercicioIF09 {

    public static void main(String args[]) {
        int dia, mes, año;

        Scanner lector = new Scanner(System.in);
        System.out.print("Dia: ");
        dia = lector.nextInt();

        System.out.print("Mes: ");
        mes = lector.nextInt();

        System.out.print("Año: ");
        año = lector.nextInt();

        switch (mes) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12: {
                if (dia >= 1 && dia <= 31) //Meses con 31 días
                {
                    System.out.println("FECHA CORRECTA!!!");
                } else {
                    System.out.println("FECHA INCORRECTA!!!");
                }
                break;
            }
            case 4:
            case 6:
            case 9:
            case 11: {
                if (dia >= 1 && dia <= 30) //Meses con 30 días
                {
                    System.out.println("FECHA CORRECTA!!!");
                } else {
                    System.out.println("FECHA INCORRECTA!!!");
                }
                break;
            }
            case 2: {
                if ((año % 4 == 0 && año % 100 != 0) || año % 400 == 0)//Comprueba que el año sea bisiesto
                {
                    if (dia >= 1 && dia <= 29) //Si es bisiesto febrero de 1 a 29
                    {
                        System.out.println("FECHA CORRECTA!!!");
                    } else {
                        System.out.println("FECHA INCORRECTA!!!");
                    }
                } else {
                    if (dia >= 1 && dia <= 28) // Sino es bisiesto febrero de 1 a 28
                    {
                        System.out.println("FECHA CORRECTA!!!");
                    } else {
                        System.out.println("FECHA INCORRECTA!!!");
                    }
                }
                break;
            }//Cierro Case2
        }//Cierro Switch
    }
}
