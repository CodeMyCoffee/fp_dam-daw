/*
 Escribe un programa que juegue con el usuario a adivinar un número. El
 ordenador debe generar un número entre 1 y 100 y el usuario tiene que
 intentar adivinarlo. Para ello, cada vez que el usuario introduce un valor, el
 ordenador debe decirle al usuario si el número que tiene que adivinar es
 mayor o menor que el que ha introducido. Cuando consiga adivinarlo debe
 indicárselo y visualizar el número de veces que el usuario ha intentado
 adivinar el número. Si el usuario introduce algo que no es un número debe
 indicarlo de esta forma en pantalla.
 */

import java.util.Scanner;

public class EjercicioBUCLES11 {

    public static void main(String args[]) {
        int numero, ocasiones = 0;
        int numeroAdivinar = (int) (Math.random() * 100 + 1);

        Scanner lector = new Scanner(System.in);

        do {
            System.out.print("Dime un numero:");
            //Se lee un valor y se espera a que el usuario pulse intro
            numero = lector.nextInt();
            lector.nextLine();

            if (numero > 0 && numero <= 100) {//Para comprobar que el usuario mete un numero correcto
                if (numeroAdivinar > numero) {
                    System.out.println("El número es mayor");
                } else  if (numeroAdivinar < numero) {
                    System.out.println("El número es menor");
                }
            } else {
                System.out.println("El número debe estar entre 0 y 100");
            }
            ocasiones++;
        }//Cierre do
        while (numero != numeroAdivinar);

        System.out.println("HAS ACERTADO!!!!");
        System.out.println("Número de intentos: " + ocasiones);
    }
}
