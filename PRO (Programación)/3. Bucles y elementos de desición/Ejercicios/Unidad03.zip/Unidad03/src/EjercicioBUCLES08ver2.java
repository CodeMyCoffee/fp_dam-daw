/*
 7. Escribe un programa que solicite un número entero e indique si se trata de
 un número primo o no.
 */
import java.util.Scanner;

public class EjercicioBUCLES08ver2 {

    public static void main(String args[]) {
        int num, contador = 2;
        boolean primo = true;
        Scanner lector = new Scanner(System.in);
        System.out.print("Introduce un número entero: ");
        num = lector.nextInt();
        //En esta versión dejamos de probar en cuanto encontramos un divisor
        while (contador < num && primo) {
            if (num % contador == 0) {
                primo = false;
            }
            contador++;
        }
        if (primo) {
            System.out.println(num + " SI es un número primo");
        } else {
            System.out.println(num + " NO es un número primo");
        }
    }
}
