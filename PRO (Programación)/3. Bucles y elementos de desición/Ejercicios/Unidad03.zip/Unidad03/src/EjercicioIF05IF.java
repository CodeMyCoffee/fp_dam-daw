import java.util.Scanner;

public class EjercicioIF05IF {
    public static void main(String args[]){
        float nota;
 
        Scanner lector = new Scanner(System.in);
        System.out.print("Dime tu nota: ");
     
        nota = lector.nextFloat();
         
       if (nota>=0 && nota <3 )
        System.out.println("MUY DEFICIENTE");
       else if (nota>=3 && nota <5 )
           System.out.println("INSUFICIENTE");
       else if (nota>=5 && nota <6 )
           System.out.println("SUFICIENTE");
       else if (nota>=6 && nota <7 )
           System.out.println("BIEN");
       else if (nota>=7 && nota <9 )
           System.out.println("NOTABLE");
       else if (nota>=9 && nota <10 )
           System.out.println("SOBRESALIENTE");
       else
           System.out.println("NOTA INCORRECTA!!");
    }
}
