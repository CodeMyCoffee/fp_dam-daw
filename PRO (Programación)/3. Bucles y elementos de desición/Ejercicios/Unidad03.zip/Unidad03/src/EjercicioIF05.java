/* Escribe un programa que permita introducir una calificación (entre cero y
 * diez) e imprima su equivalente alfabético, según la siguiente tabla.
 * · De 3 -------> M.D.
 * · Desde 3 y menor que 5 -------> INS.
 * · Desde 5 y menor que 6 -------> SUF.
 * · Desde 6 y menor que 7 -------> BIEN
 * · Desde 7 y menor que 9 -------> NOT.
 * · Desde 9 hasta 10 -------> SOB.
 */
import java.util.Scanner;

public class EjercicioIF05 {

    public static void main(String args[]) {
        int nota;
        //Se declara el objeto lector de la clase Scanner
        Scanner lector = new Scanner(System.in);
        System.out.print("Dime tu nota: ");
        //Se lee un valor 
        nota = lector.nextInt();

        switch (nota) {
            case 0:
            case 1:
            case 2:
                System.out.println("MUY DEFICIENTE");
                break;
            case 3:
            case 4:
                System.out.println("INSUFICIENTE");
                break;
            case 5:
                System.out.println("SUFICIENTE");
                break;
            case 6:
                System.out.println("BIEN");
                break;
            case 7:
            case 8:
                System.out.println("NOTABLE");
                break;
            case 9:
            case 10:
                System.out.println("SOBRESALIENTE");
                break;
            default:
                System.out.println("NOTA INCORRECTA!!!");

        }

    }
}
