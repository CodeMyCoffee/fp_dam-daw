
/*
 Escribe un método que acepte dos argumentos: el carácter que se desea
 imprimir y el número de veces que se imprime
 */
import java.util.Random;

public class Ejercicio06 {

    static void imprime(char a, int b) {
        int contador = 0;
        while (b > contador) {
            System.out.print(a);
            contador++;
        }
    }

    public static void main(String args[]) {
       
        int nveces;
        char car;
      
        for (car = 'a'; car <= 'z'; car++) {
            Random dameNumero = new Random();
            nveces = dameNumero.nextInt(30);
            System.out.print("\n"+car + "\t" + nveces + " veces:\t");
            imprime(car, nveces);
        }
        System.out.println();
    }
}
