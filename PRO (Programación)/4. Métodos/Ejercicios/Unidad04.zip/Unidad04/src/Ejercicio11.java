/*
Escríbase un método que dados 4 números enteros pasados como
parámetros, compruebe si dicha secuencia de números es capicúa.
 */
public class Ejercicio11 {

    static boolean capicua(int num1, int num2, int num3, int num4) {
        if (num1 == num4 && num2 == num3) {
           return true;
        } else {
           return false;
        }
    }

    public static void main(String[] args) {
        for (int i = 1; i <= 20; i++) {//Bucle para generar 10 numeros aleatorios
            int num1 = (int) (Math.random() * 9 + 0); //Numero aleatorio entre 0 y 9 (DIGITOS
            int num2 = (int) (Math.random() * 9 + 0);
            int num3 = (int) (Math.random() * 9 + 0);
            int num4 = (int) (Math.random() * 9 + 0);
            if (capicua(num1, num2, num3, num4))
                 System.out.println(num1 + " " + num2 + " " + num3 + " " + num4 + " es CAPICUA");
            else
             System.out.println(num1 + " " + num2 + " " + num3 + " " + num4 + " NO es CAPICUA");    

        }
    }
}
