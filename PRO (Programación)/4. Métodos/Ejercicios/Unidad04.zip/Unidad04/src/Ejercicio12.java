/*
 Escribe un programa en Java que, dado el nombre de una persona y el
 idioma de preferencia de esa persona, escriba en pantalla un saludo a esa
 persona en el idioma elegido, con el estilo: ”Buenos días Pepe Sánchez”.
 Los idiomas disponibles serán
 (a) Valenciano
 (b) Castellano
 (c) Inglés
 El saludo se mostrará desde un procedimiento al que se le pasan el
 nombre y el código del idioma. Para el ejemplo anterior, la llamada sería:
 saludo (”Pepe Sánchez ”, ’b’)
 */

import java.util.Scanner;

public class Ejercicio12 {

    public static void menu() {
        System.out.println("*****IDIOMAS******");
        System.out.println("(V)Valenciano");
        System.out.println("(C)Castellano");
        System.out.println("(I)Inglés");
        //System.out.println("******************");
        System.out.println("(F) Finalizar");
        System.out.println("******************");

    }
    /*
     static String hola(String nombre, char idioma) {
     String saludo;
     switch (idioma) {
     case 'v':
     case 'V':
     saludo = "Bon dia " + nombre;
     break;
     case 'c':
     case 'C':
     saludo = "Buenos dias " + nombre;
     break;
     case 'i':
     case 'I':
     saludo = "Good Morning " + nombre;
     break;
     default:
     saludo = "Hola" + nombre;

     }
     return saludo;
     }

     * // nombre=   hola("Pepe",'v');
     */

    public static void saludo(String nombre, char opcion) {

        switch (opcion) {
            case ('v'):
            case ('V'):
                System.out.println("Bon dia " + nombre);
                break;
            case ('c'):
            case ('C'):
                System.out.println("Buenos días " + nombre);
                break;
            case ('i'):
            case ('I'):
                System.out.println("Good Morning " + nombre);
                break;
            //case ('f'):
            //case ('F'):
            //  System.out.println("fin...");
            //break;
            default:
                System.out.println("OPCION INCORRECTA!!");
        }
    }

    public static void main(String[] args) {
        String nombre;
        String resp;
        char opcion;
        Scanner lector = new Scanner(System.in);

        do {
            System.out.println();
            menu();
            System.out.print("Elija un idioma: ");
            resp = lector.nextLine();
            opcion = resp.charAt(0); //Leer Carácter
            if (opcion != 'f' && opcion != 'F') {
                System.out.print("Digame su nombre: ");
                nombre = lector.nextLine();
                saludo(nombre, opcion);
            }
        } while (opcion != 'F' && opcion != 'f');

    }
}
