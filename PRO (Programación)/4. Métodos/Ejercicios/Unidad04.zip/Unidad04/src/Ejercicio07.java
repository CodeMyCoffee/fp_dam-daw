/*
 Escribe un método que acepte tres argumentos: un carácter y dos enteros.
 El carácter se debe imprimir. El primer entero indica el número de veces
 que se imprimirá el carácter en la línea y el segundo entero indica el
 número de líneas que deben imprimir-se.
 */

import java.util.Scanner;

public class Ejercicio07 {

    /* Otra opción
    static void imprimeLineas(char a, int num, int linea) {
        int contador = 0;
        while (linea > contador) {
            Ejercicio06.imprime(a, num); //Utilizo el método del ejercicio 06
            System.out.println();
            contador++;
        }
    }*/

    static void imprime(char caracter, int num, int lineas) {
        for (int contador = 1; contador<=lineas ; contador++) {
            Ejercicio06.imprime(caracter, num); //Utilizo el método del ejercicio 06
            System.out.println();
        }
    }

    public static void main(String args[]) {
        String resp;
        int nveces, lineas;
        Scanner lector = new Scanner(System.in);
        do {
            System.out.print("Carácter: ");
            resp = lector.nextLine();
            char caracter = resp.charAt(0); //Leer Carácter
            System.out.print("Número de columnas:");
            nveces = lector.nextInt();
            lector.nextLine();

            System.out.print("Número de líneas:");
            lineas = lector.nextInt();
            lector.nextLine();
            //imprimeLineas(caracter, nveces, lineas);
            imprime(caracter, nveces, lineas);
            System.out.print("Quieres seguir dibujando? (si / no) ");
            resp = lector.nextLine();

        } while (resp.compareToIgnoreCase("si") == 0);
    }
}
