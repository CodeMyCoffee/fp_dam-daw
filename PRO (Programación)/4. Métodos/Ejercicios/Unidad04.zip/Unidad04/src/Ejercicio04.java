
/*
 Escribe un método que devuelva el mayor de tres números
 */
import java.util.Random;
public class Ejercicio04 {

   static int maximo(int a, int b) {
        return a >= b ? a : b;
    }
   

    static int maximo(int a, int b, int c) {
        return Ejercicio03.maximo(Ejercicio03.maximo(a, b), c);
    }

    public static void main(String args[]) {
        int num1, num2, num3, max, i;

        Random dameNumero = new Random();

        for (i = 1; i <= 20; i++) {
            num1 = dameNumero.nextInt(1000);
            num2 = dameNumero.nextInt(1000);
            num3 = dameNumero.nextInt(1000);
            max = maximo(num1, num2, num3);
            System.out.println("El mayor entre: " + num1 + ", " + num2 + " y " + num3 + " es: " + max);
        }
    }
}