/*
Escribe un método que devuelva el mayor de dos números
 */

public class Ejercicio03 {

    static int maximo(int a, int b) {
       return a>=b ? a:b ; 
    }


    public static void main(String args[]) {
        int num1=5,num2=8,max;
        max=maximo(num1,num2);
        System.out.println("Maximo: "+max);
    }
}

