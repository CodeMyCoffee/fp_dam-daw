
/*
Diseña un método que devuelva el mayor de cuatro números que se le
pasan como argumentos.
 */
import java.util.Random;
public class Ejercicio05 {
 
  static int maximo(int a, int b) {
       return a>=b ? a:b ; 
    }
  static int maximo(int a, int b, int c) {
        return maximo(maximo(a, b), c);
    }
  static int maximo(int a, int b, int c, int d) {
        return maximo(maximo(a, b, c), d);
    }

  public static void main(String args[]) {
        int num1, num2, num3, num4, max, i;

        Random dameNumero = new Random();

        for (i = 1; i <= 20; i++) {
            num1 = dameNumero.nextInt(1000);
            num2 = dameNumero.nextInt(1000);
            num3 = dameNumero.nextInt(1000);
            num4 = dameNumero.nextInt(1000);
            max = maximo(num1, num2, num3, num4);
            System.out.println("El mayor entre: " + num1 + ", " + num2 +" , "+ num3+ " y " + num4 + " es: " + max);
        }
    }
}