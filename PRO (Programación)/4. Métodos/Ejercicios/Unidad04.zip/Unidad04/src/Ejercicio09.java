/*Se llama media armónica de dos números el resultado obtenido al
calcular los inversos de los números, calcular la media y calcular el inverso
del resultado. Escribe un método que acepte dos argumentos double i
devuelva la media armónica de los números.
 */
import java.util.Random;

public class Ejercicio09 {

    static double inverso( double a){
        return 1/a;
    }
    static double media(double a, double b){
        return (a+b)/2;
    }
    static double mediaarmonica(double a, double b) {
        double mediaarm;
        mediaarm= inverso(media(inverso(a), inverso(b) ));
        return mediaarm;
    }

    public static void main(String args[]) {
        double  armonic;
        int num1, num2;
        int i;
          Random dameNumero = new Random();

        for (i = 1; i <= 20; i++) {
            num1 = dameNumero.nextInt(100);
            num2 = dameNumero.nextInt(100);
            armonic=mediaarmonica(num1,num2);
            System.out.printf ("La media armónica de %3d y %3d es %.2f \n" ,num1, num2, armonic);
        }
    }
}
