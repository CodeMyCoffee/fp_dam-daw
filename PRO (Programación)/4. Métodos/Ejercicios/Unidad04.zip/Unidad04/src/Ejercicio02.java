/*
 Escribe un programa que calcule el área y la longitud de una
 circunferencia en función del radio (leído desde teclado). Se ha de escribir
 un método para calcular el área y otro para la longitud. Las fórmulas del
 área y la longitud de una circunferencia: A=p * r2 y L=2*p * r
 */

import java.util.*;

public class Ejercicio02 {

    static double area(double r) {
        double area = Math.PI * Math.pow(r, 2);
        return area;
    }

    static double longitud(double r) {
        double longitud = 2 * Math.PI * r;
        return longitud;
    }

    public static void main(String args[]) {
        double radio, area, longitud;

        Scanner lector = new Scanner(System.in);

        do {
            //Leo radio
            System.out.print("Introduce otro radio. ( ZERO para finalizar) ");
            radio = lector.nextDouble();
            lector.nextLine();
            // Calculamos con las funciones
            area = area(radio);
            longitud = longitud(radio);
            //Mostramos por pantalla
            System.out.println("Area: " + area);
            System.out.println("Longitud: " + longitud);

        } while (radio > 0);

    }
}
