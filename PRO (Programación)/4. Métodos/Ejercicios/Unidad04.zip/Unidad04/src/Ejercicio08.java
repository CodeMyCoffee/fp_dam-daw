/*
 Escribe una método que acepte dos argumentos: el carácter que se desea
 imprimir y el número de líneas que se imprimen en forma triangular
 a
 aaa
 aaaaa
 aaaaaaa*/

public class Ejercicio08 {

    static void imprimetriangulo(char a, int linea) {
        //Versión más compacta
        /*int i;
         for (i = 1; i <= linea; i++) {
         Ejercicio06.imprime(' ', linea - i);
         Ejercicio06.imprime(a, i * 2 - 1);
         System.out.println();
         }*/
        int i;
        int vecesBlanco = linea ; //o veces=linea-1;
        int vecesCaracter = 1;
        for (i = 1; i <= linea; i++) {
            Ejercicio06.imprime(' ', vecesBlanco);
            Ejercicio06.imprime(a, vecesCaracter);
            vecesBlanco--;
            vecesCaracter += 2;
            System.out.println();
        }
    }

    public static void main(String args[]) {

        int lineas = 1;
        char car;

        for (car = 'a'; car <= 'z'; car++) {
            imprimetriangulo(car, lineas++);
            System.out.println();
        }
    }
}
