/*
 Escribe un programa que solicite un número y visualizar en pantalla si es
 o no un número perfecto.
 Un número se considera perfecto cuando la suma de sus divisores,
 excepto el mismo, es igual al propio número.
 * Así, 6 es un número perfecto, porque sus divisores propios son 1, 2 y 3; y 6 = 1 + 2 + 3. 
 * Así, 28 es un número perfecto, porque sus divisores propios son 1, 2, 4, 7 y 14; y 1 + 2 + 4 + 7 + 14 = 28.
 * Los siguientes números perfectos son 28, 496 y 8128.
 */

public class Ejercicio13 {

    public static boolean divisor(int dividendo, int divisor) {
        if (dividendo % divisor == 0) {
            return true;
        } else {
            return false;
        }
    }

    public static boolean perfecto(int num) {
        int candidato ;
        int suma = 0;
        int tmp = num;
        for (candidato=1; candidato < num; candidato++){
            if (divisor(num, candidato)) {
                suma += candidato;
            }
        }
        if (suma == num) {
            return true;
        } else {
            return false;
        }
    }

    public static void main(String[] args) {
        int i;
        for (i = 1; i <= 100; i++) {
            if (perfecto(i)) {
                System.out.println(i + " es PERFECTO");
            } else {
                System.out.println(i + " NO es PERFECTO");
            }
        }
    }
}
