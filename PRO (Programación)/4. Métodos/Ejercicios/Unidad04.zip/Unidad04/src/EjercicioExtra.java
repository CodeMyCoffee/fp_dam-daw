/*
 * 0.5p) Un método estático llamado escribe( ) que acepte dos argumentos: el carácter que se desea imprimir y el número de veces que se imprime.
El método debe mostrar por pantalla el carácter dado, ese número de veces. Por ejemplo:
escribe(b,3) mostrará por pantalla bbb
b) (2p) Escribe un método main que utilice el método anterior y muestre por pantalla:
       a
      bbb
     ccccc
    ddddddd
   eeeeeeeee
…….. hasta…….
zzzzzzzzzzzzzzzzz
 */

public class EjercicioExtra {

    static void escribe(char a, int b) {
        int contador = 0;
        while (b > contador) {
            System.out.print(a);
            contador++;
        }
    }

    public static void main(String args[]) {

        int vecesBlanco = 30;
        int vecesCaracter = 1;
        for (char car = 'a'; car <= 'z'; car++) {
            escribe(' ', vecesBlanco);
            escribe(car, vecesCaracter);
            vecesBlanco--;
            vecesCaracter += 2;
            System.out.println();
        }
    }
}
