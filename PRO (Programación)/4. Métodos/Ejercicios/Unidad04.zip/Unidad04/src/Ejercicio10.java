/*
Escribe un método que acepte un entero y calcule su factorial n!
 */

public class Ejercicio10 {

    static long  factorial(int a) {
       long fact=1;
       
        while (a > 0) {
            fact=fact*a;
            a--;
        }
        return fact;
    }

    public static void main(String args[]) {
        int i;
        System.out.println();
         for (i = 1; i <= 20; i++) {
             System.out.printf(" %3d! = %23d \n " , i, factorial(i));
        }
    }
}
