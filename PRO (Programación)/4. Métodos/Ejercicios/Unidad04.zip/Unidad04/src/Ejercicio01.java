/*Escribe un método que devuelva la suma de dos enteros.*/

import java.util.*;

public class Ejercicio01 {

    static int suma(int a, int b) {
        return a + b;
    }

    public static void main(String args[]) {
        Random dameNumero = new Random();
        int i, num1, num2;
        for (i = 1; i <= 20; i++) {
            num1 = dameNumero.nextInt(1000);
            num2 = dameNumero.nextInt(1000);
            System.out.println("La suma de: " + num1 + " y " + num2 + " es: " + suma(num1, num2));
        }
    }
}
