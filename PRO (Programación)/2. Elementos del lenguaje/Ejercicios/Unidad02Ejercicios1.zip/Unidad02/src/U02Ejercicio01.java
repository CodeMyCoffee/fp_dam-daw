/*1.- Escribir un programa que escriba en la pantalla tu nombre completo 
 * en una línea y en la línea siguiente tu fecha de nacimiento.
 * */

public class U02Ejercicio01 {

    public static void main(String[] args) {
//sin variables
        System.out.print("José Miguel Soler Montalvo\n07/06/1993\n");
//con variables String
        String nombre = "Antonio";
        String apell1 = "Donoso";
        String apell2 = "Hurtado";
        String fechaNac = "11/11/1987";

        System.out.println(nombre + " " + apell1 + " " + apell2);
        System.out.println(fechaNac);
    }
}
