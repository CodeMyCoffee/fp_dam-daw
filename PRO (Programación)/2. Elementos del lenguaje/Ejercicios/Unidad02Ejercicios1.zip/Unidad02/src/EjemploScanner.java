
import java.util.Scanner;

/*
 *ejemplo Scanner
 */
public class EjemploScanner {

    public static void main(String[] args) {
        int entero;
        double real;
        boolean siOno;
        char caracter;
        String texto; //no es un tipo primitivo

        Scanner lector = new Scanner(System.in);

        System.out.print("Introduce un entero: ");
        entero = lector.nextInt();
        System.out.println("El entero introducido es " + entero);

        System.out.print("Introduce un real: ");
        real = lector.nextDouble();
        //ATENCION! el programa fallara si el usuario entra el numero con punto decimal
        System.out.println("El real introducido es " + real);

        System.out.print("Introduce si o no: ");
        siOno = lector.nextBoolean();
        //ATENCION! el programa fallara si el usuario no entra true o false
        System.out.println("El boolean introducido es  " + siOno);

        lector.nextLine();
        //ATENCION! con esta instrucción limpio el buffer de entrada
        //si no la pongo, no me deja entrar el carácter posterior
        //encuentra el salto de linea y considera que esa es la tira introducida
        //pruébalo!

        System.out.print("Introduce un caracter: ");
        caracter = lector.nextLine().charAt(0);
        //ATENCION! leo un String y me quedo con el primer carácter
        System.out.println("El caracter introducido es  " + caracter);

        //lector.nextLine();
        //Hace falta aquí limpiar el buffer de entrada?

        System.out.print("Introduce tu nombre: ");
        texto = lector.nextLine();
        System.out.println("Tu nombre es  " + texto);

    }
}
