/* 17.- Escribe un programa que solicite al usuario una cantidad en segundos
 * y la convierta a días, horas, minutos y segundos.
 * */

import java.util.Scanner;

public class U02Ejercicio17 {

    public static void main(String[] args) {
        int lectura;
        int seg, min, horas, dias;
        Scanner lector = new Scanner(System.in);

        System.out.print("Introduce los segundos: ");
        lectura = lector.nextInt();
        lector.nextLine();

        min = lectura / 60;
        seg = lectura % 60;
        horas = min / 60;
        min = min % 60;
        dias = horas / 24;
        horas = horas % 24;

        System.out.println(lectura + " segundos son : " + dias + " dias " + horas + " h " + min + " \' " + seg + " \" ");

    }
}
