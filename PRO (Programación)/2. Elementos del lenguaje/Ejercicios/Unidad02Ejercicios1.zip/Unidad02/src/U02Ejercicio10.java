/* 10.- Dadas las siguientes expresiones aritméticas, calcula cuál es el resultado de evaluarlas. Supón que las variables a y b que aparecen son del tipo int y a tiene el valor de 2 y b tiene el valor de 4.
 a) –a + 5 % b – a * a
 b) 5 + 3 % 7 * b * a – b % a
 c) (a+1) * (b + 1) – b / a
 */

public class U02Ejercicio10 {

    public static void main(String[] args) {
        int a = 2;
        int b = 4;
        int resul;

        resul = -a + 5 % b - a * a;
        System.out.println("-a + 5%b - a * a = " + resul);
        //(-a) + (5 % b) - (a * a);
        resul = 5 + 3 % 7 * b * a - b % a;
        System.out.println("5 + 3%7 * b * a - b%a = " + resul);
        //5 + (((3 % 7) * b) * a) - (b % a)
        resul = (a + 1) * (b + 1) - b / a;
        System.out.println("(a + 1) * (b + 1) - b/a = " + resul);
        //(a + 1) * (b + 1) - (b / a);
    }
}
