/* 18.- Escribe un programa que solicite al usuario el tamaño del lado de 
 * un triángulo equilátero y calcule su perímetro y su área.
 */
public class U02Ejercicio18 {

    public static void main(String[] args) {
        int entrada;
        double area, perimetro;

        java.util.Scanner lector = new java.util.Scanner(System.in);

        System.out.print("Introduce el lado del triangulo: ");
        entrada = lector.nextInt();

        System.out.println("Lado del triangulo: " + entrada);

        perimetro = entrada * 3;
        area = Math.pow(entrada, 2) * (Math.sqrt(3) / 4);

        System.out.println("Area =\t" + area);
        System.out.println("Perimetro =\t" + perimetro);

    }
}
