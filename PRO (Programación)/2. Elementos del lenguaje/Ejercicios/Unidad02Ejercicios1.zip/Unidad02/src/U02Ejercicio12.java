/*12.- Escribe un programa para calcular el área y el volumen de un cilindro. 
 * Para ello declara una constante que guarda el valor de PI. Declara, también, 
 * variables para el diámetro y la altura del cilindro. 
 * Supón para el ejemplo que el cilindro tiene un diámetro de 15,5cm 
 * y una altura de 42,4cm.
 * */

public class U02Ejercicio12 {

    public static void main(String[] args) {
        //final float pi = 3.14f;
        double diam = 15.5;
        double alto = 42.4;
        double area;
        double volumen;
        double radio = diam / 2;

        area = (2 * Math.PI * radio) * (alto + radio);  //A = 2 Π r ( r + h )
        volumen = Math.PI *  Math.pow(radio, 2) * alto;  //V = Π r 2·h

        System.out.println("Alto:\t\t" + alto);
        System.out.println("Diametro:\t" + diam);
        System.out.println("Area:\t\t" + area);
        System.out.println("Volumen:\t" + volumen);
    }
}