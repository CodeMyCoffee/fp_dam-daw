/*15.- Escribe un programa que defina un enumerado para los días de la semana.
 * En el programa define una variable del enumerado y asígnale el valor del día
 * que corresponda al martes. 
 * A continuación, escribe por pantalla dicha variable y escribe el valor del 
 * enumerado correspondiente al domingo.
 */

public class U02Ejercicio15 {

    public enum diasSemana {

        LUNES, MARTES, MIERCOLES, JUEVES, VIERNES, SABADO, DOMINGO
    };

    public static void main(String[] args) {
        diasSemana hoy = diasSemana.MARTES;
        diasSemana dia = diasSemana.DOMINGO;
        System.out.println("Hoy es " + hoy);
        System.out.println("Hoy no es "+ diasSemana.JUEVES);
        System.out.println("Domingo es el dia numero " + (dia.ordinal() + 1));
      
       
    }
}
