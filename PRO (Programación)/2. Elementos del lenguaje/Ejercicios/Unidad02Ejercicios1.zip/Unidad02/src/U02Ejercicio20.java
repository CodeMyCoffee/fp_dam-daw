/* 20.- Escribe un programa que calcule cuánto te dará tu banco después de 
 * realizar una imposición a plazo fijo. 
 * Para ello el programa debe pedir la cantidad que desea invertir en el banco,
 * el tipo de interés anual que le paga el banco por el dinero y el plazo que 
 * se mantiene la inversión. 
 * El programa debe calcular el dinero que se obtiene después de dicho plazo. 
 * Recuerda que al pagarte los intereses el banco te retendrá el 18% para hacienda. 
 * Escribe los mensajes apropiados para que el usuario pueda 
 * seguir el proceso de cálculo realizado.
 * */

import java.util.Scanner;

public class U02Ejercicio20 {

    public static void main(String[] args) {
        int cantidad;
        float interes;
        int retHac = 18;
        float beneficio, retencion, cantidadFinal;
        float tiempo;//en años
        Scanner lector = new Scanner(System.in);
        
        System.out.print("Introduce la cantidad: ");
        cantidad = lector.nextInt();
        System.out.print("Introduce el tipo de interes: ");
        interes = lector.nextFloat();
        System.out.print("Introduce la duracion del plazo (en años) : ");
        tiempo = lector.nextInt();

        beneficio = ((cantidad * interes) / 100) * tiempo;
        retencion = (beneficio * retHac) / 100;
        cantidadFinal = cantidad + beneficio - retencion;

        System.out.println();
        System.out.println("\tCantidad inicial: " + cantidad + " €");
        System.out.println("\tIntereses anuales: " + beneficio + " €");
        System.out.println("\tRetencion Hacienda: " + retencion + " €");
        System.out.println("\tCantidad final: " + cantidadFinal + " €");
        System.out.println();
    }
}
