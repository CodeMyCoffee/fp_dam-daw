/*11.- 11.- Escribe un programa que defina dos variables enteras para describir 
 * las longitudes de los lados de un rectángulo. El programa debe calcular y 
 * escribir en la pantalla las longitudes de los lados, el perímetro y el área 
 * del rectángulo. (Supón que el rectángulo mide 15 cm de alto y 25 cm de ancho.)
 */

public class U02Ejercicio11 {

    public static void main(String[] args) {
        int alto = 15;
        int ancho = 25;
        int perim;
        int area;

        perim = (alto * 2) + (ancho * 2);
        area = alto * ancho;

        System.out.println("Alto:\t\t" + alto);
        System.out.println("Ancho:\t\t" + ancho);
        System.out.println("Perimetro:\t" + perim);
        System.out.println("Area:\t\t" + area);
    }
}
