/* 3.- Escribe un programa que escriba en pantalla las notas de la asignatura de
 * “Programación”. En la primera línea se escribirá el nombre de la asignatura.
 * En las siguientes líneas se escribirán las notas de los dos parciales 
 * realizados poniendo la nota de cada uno en líneas distintas. 
 * En la última línea escribirá la nota final de la asignatura. 
 * Escribe lo que sea texto como un texto entre comillas dobles y lo que sea 
 * número como un número.
 */
public class U02Ejercicio03 {

    public static void main(String[] args) {
        double parcial1 = 8.2;
        double parcial2 = 6.5;
        double  notaFinal;
        System.out.println("Programación");
        System.out.print("Parcial 1 = ");
        System.out.println(parcial1);
        System.out.print("Parcial 2 = ");
        System.out.println(parcial2);
        notaFinal = (parcial1 + parcial2) / 2;
        System.out.print("Final = ");
        System.out.println(notaFinal);
    }
}
