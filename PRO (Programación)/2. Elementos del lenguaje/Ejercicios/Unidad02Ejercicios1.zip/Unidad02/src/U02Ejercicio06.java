/*6.- Escribe un programa que visualice en pantalla cuánto le costará comprar
 * unas deportivas cuyo precio de catálogo es de 85,00 €, 
 * si sabe que puede conseguir una rebaja del 15%.
 */

public class U02Ejercicio06 {

    public static void main(String[] args) {
        float precio = 85;
        int rebaja = 15;
        float total;
        total = (precio * 15) / 100;
        total = precio - total;

        System.out.println("Precio = " + precio + "€");
        System.out.println("Descuento = " + rebaja + "%");
        System.out.println("Precio Final = " + total + "€");
    }
}
