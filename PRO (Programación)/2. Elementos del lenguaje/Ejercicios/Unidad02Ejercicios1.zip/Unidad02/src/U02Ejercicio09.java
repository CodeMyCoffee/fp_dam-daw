/*9.- Dadas las siguientes expresiones aritméticas, calcula cuál es el resultado de evaluarlas:
 a) 25 + 20 -15
 b) 20 * 10 +15 * 10
 c) 20 * 10 / 2 -20 /5 * 3
 d) 15/10*2 + 3 / 4 * 8
 */

public class U02Ejercicio09 {

    public static void main(String[] args) {
        float resultado;

        resultado = 25 + 20 - 15;
        System.out.println("25 + 20 - 15 = " + resultado);
        //(25 + 20)- 15
        resultado = 20 * 10 + 15 * 10;
        System.out.println("20 * 10 +15 * 10 = " + resultado);
        //  (20 * 10) + (15 * 10)
        resultado = 20 * 10 / 2 - 20 / 5 * 3;
        //((20 * 10) / 2) - ((20 / 5) * 3)
        System.out.println("20 * 10/2 - 20/5 * 3 = " + resultado);
        resultado = 15 / 10 * 2 + 3 / 4 * 8;
        System.out.println("15/10 * 2 + 3/4 * 8 = " + resultado);
        //((15 / 10) * 2) + ((3 / 4) * 8);
    }
}
