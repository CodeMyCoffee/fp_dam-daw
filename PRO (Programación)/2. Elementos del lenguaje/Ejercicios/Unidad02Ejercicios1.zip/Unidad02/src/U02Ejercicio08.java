public class U02Ejercicio08 {

    public static void main(String[] args) {
        int cantidad = 2000;
        float interes = 2.75f;
        int retHac = 18;
        float beneficio, retencion, cantidadFinal;
        float tiempo = 0.5f;//en años

        System.out.println("Cantidad inicial: " + cantidad);
        beneficio = ((cantidad * interes) / 100); //anual
        System.out.println("Intereses anuales: " + beneficio);
        beneficio = beneficio / 2;
        System.out.println("Intereses a los 6 meses: " + beneficio);
        retencion = (beneficio * retHac) / 100;
        System.out.println("Retencion Hacienda: " + retencion);
        beneficio = beneficio - retencion;
        System.out.println("Interes neto: " + beneficio);
        cantidadFinal = cantidad + beneficio;
        System.out.println("Cantidad final: " + cantidadFinal);
    }
}
