/* 7.- Escribe un programa que visualice en pantalla cuánto le dará su banco
 * después de seis meses si pone 2000€ en una cuenta a plazo fijo al 2,75% anual.
 * Recuerda que al pagarte los intereses el banco le retendrá el 18% para hacienda.
 */

public class U02Ejercicio07 {

    public static void main(String[] args) {
        int cantidad = 2000;
        float interes = 2.75f;
        int retHac = 18;
        float beneficio, retencion, cantidadFinal;
        float tiempo = 0.5f;//en años

        beneficio = ((cantidad * interes) / 100) * tiempo;
        retencion = (beneficio * retHac) / 100;
        cantidadFinal = cantidad + beneficio - retencion;

        System.out.println("Cantidad inicial: " + cantidad);
        System.out.println("Cantidad final: " + cantidadFinal);

    }
}
