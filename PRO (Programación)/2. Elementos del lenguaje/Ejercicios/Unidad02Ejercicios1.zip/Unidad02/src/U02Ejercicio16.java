/*
 16.- Escribe en Java los siguientes tipos enumerados:
 a) Los días de la semana
 b) Las calificaciones de un alumno
 c) los colores primarios (rojo, amarillo, azul)
 d) Las notas musicales
 */

public class U02Ejercicio16 {

    public enum diasSemana {

        LUNES, MARTES, MIERCOLES, JUEVES, VIERNES, SABADO, DOMINGO
    };

    public enum calAlumnos {

        SOBRESALIENTE, NOTABLE, BIEN, SUFICIENTE, SUSPENSO
    };

    public enum colPrimarios {

        ROJO, AMARILLO, AZUL
    };

    public enum notMusicales {

        DO, RE, MI, FA, SOL, LA, SI
    };
}
