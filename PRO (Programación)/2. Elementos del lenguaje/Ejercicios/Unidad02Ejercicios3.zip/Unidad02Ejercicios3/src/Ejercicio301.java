/*1. - Introducir dos números y calcular la suma de los mismos, visualizando el
 resultado final. Repetir para la resta y la multiplicación.*/

import java.util.Scanner;

public class Ejercicio301 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int num1, num2;
        System.out.println("Piensa un número: ");
        num1 = teclado.nextInt();
        System.out.println("Piensa otro número: ");
        num2 = teclado.nextInt();
        System.out.println("Suma: " + (num1 + num2)
                + "\nResta: " + (num1 - num2)
                + "\nMultiplicación: " + (num1 * num2));

    }
}
