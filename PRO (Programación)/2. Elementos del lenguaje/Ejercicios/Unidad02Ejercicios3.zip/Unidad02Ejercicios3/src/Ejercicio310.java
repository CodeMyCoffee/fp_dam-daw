/*10. - Introducir dos números A y B y visualizarlos en orden creciente.
  Repetir para orden decreciente.*/

import java.util.*;

public class Ejercicio310 {

    public static void main(String[] args) {
        int a, b;
        Scanner teclado = new Scanner(System.in);

        System.out.print("Introduce un número: ");
        a = teclado.nextInt();
        System.out.print("Introduce un número: ");
        b = teclado.nextInt();

        System.out.print("***Orden creciente  ");
        if (a < b) {
            System.out.println(a + ", " + b);
        } else {
            System.out.println(b + ", " + a);
        }
        System.out.print("***Orden decreciente  ");
        if (a < b) {
            System.out.println(b + ", " + a);
        } else {
            System.out.println(a + ", " + b);
        }
    }
}
