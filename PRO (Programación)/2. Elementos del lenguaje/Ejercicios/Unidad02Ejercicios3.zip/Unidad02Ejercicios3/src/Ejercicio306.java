/*6. - Introducir una temperatura en grados centígrados y visualizar su
equivalente en grados Kelvin y grados Fahrenheit.
Grados Kelvin = 273 + grados Celsius.
Grados Fahrenheit. = (grados Celsius / 5 ) * 9) + 32
*/

import java.util.Scanner;

public class Ejercicio306 {

    public static void main(String[] args) {
        int temperatura;
        int kelvins, fahrenheit;
        Scanner teclado = new Scanner(System.in);
       
        System.out.print("Inserte los grados: ");
        temperatura = teclado.nextInt();
        kelvins = 273 + temperatura;
        fahrenheit = (temperatura / 5) * 9 + 32;
        System.out.println("Kelvin: " + kelvins + "\n"
                + "Fahrenheit :" + fahrenheit);
    }
}
