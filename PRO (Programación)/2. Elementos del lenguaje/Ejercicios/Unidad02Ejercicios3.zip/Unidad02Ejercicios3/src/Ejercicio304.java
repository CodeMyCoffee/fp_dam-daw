/*4. - Introducir un número A y calcular B. B= A * (A+5) / A + (A*5)*/

import java.util.*;

public class Ejercicio304 {

    public static void main(String[] args) {
        double numA;
        Scanner teclado = new Scanner(System.in);
        System.out.println("Inserte numero:");
        numA = teclado.nextDouble();
        System.out.println("B: " + (numA * (numA + 5) / numA + (numA * 5)));
    }
}
