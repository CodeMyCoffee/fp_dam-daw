/*7. - Introducir un valor en Kilómetros y visualizar su equivalente en Milla
 Terrestre y Milla Marina.
 Milla terrestre = 1.609,34 m.
 Milla marina = 1.852,00 m.*/

import java.util.Scanner;

public class Ejercicio307 {

    public static void main(String[] args) {
        double kilometros;
double millaTerrestre, millaMarina;
        Scanner teclado = new Scanner(System.in);
        
        System.out.print("Kilometros: ");
        kilometros = teclado.nextDouble();
        millaTerrestre = kilometros*1000/ 1609.34;
        millaMarina = kilometros*1000 /1852.0;

        System.out.println("Milla terrestre: " + millaTerrestre
                + "\nMilla marina: " + millaMarina);

    }
}
