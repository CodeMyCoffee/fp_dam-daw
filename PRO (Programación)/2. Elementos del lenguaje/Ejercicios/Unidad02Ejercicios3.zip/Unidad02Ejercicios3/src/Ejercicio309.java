/*9. - Introducir dos números A y B.
  Si A es mayor que B calcular y visualizar A + B y A / B.
  Si A no es mayor que B calcular y visualizar A * B y B - A.*/

import java.util.*;

public class Ejercicio309 {

    public static void main(String[] args) {

        double a, b;
        double suma, division, mult, resta;
        Scanner teclado = new Scanner(System.in);

        System.out.print("Introduce un numero A: ");
        a = teclado.nextDouble();
        System.out.print("Introduce un numero B: ");
        b = teclado.nextDouble();

        if (a > b) {
            suma = a + b;
            division = a / b;
            System.out.println("A+B=" + suma + "\n" + "A/B=" + division);

        } else {
            mult = a * b;
            resta = b - a;
            System.out.println("AxB=" + mult + "\n" + "B-A=" + resta);

        }
    }
}
