/*5. - El programa debe decir al usuario que piense un número, a continuación
 indicar al usuario que al número que él ha pensado, lo multiplique por 5,
 después que le sume 6, a continuación que lo multiplique por 4, que le
 sume 9 y que lo multiplique por 5.
El programa solicitará el resultado de ese cálculo. A ese número
restará 165 y luego lo dividirá por 100. Mostrará el resultado. Ese
será el número que el usuario había pensado.*/

import java.util.Scanner;

public class Ejercicio305 {

    public static void main(String[] args) {
        int numeroPensado, calculo;

        Scanner teclado = new Scanner(System.in);
        System.out.println("Piensa un número... ");        teclado.nextLine();
        System.out.println("multiplicalo por 5...");  teclado.nextLine();
        System.out.println("sumale 6..."); teclado.nextLine();
        System.out.println("Ahora multiplicalo por 4...");  teclado.nextLine();
        System.out.println("sumale 9..."); teclado.nextLine();
        System.out.println("y multiplicalo por 5..."); teclado.nextLine();
        System.out.println("\nInserte el numero resultante: ");
        numeroPensado = teclado.nextInt();
        
        calculo = (numeroPensado - 165) / 100;
        System.out.println("\nEl número es: " + calculo);

    }
}
