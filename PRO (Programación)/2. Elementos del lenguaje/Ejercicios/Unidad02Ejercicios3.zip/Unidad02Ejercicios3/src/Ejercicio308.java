/*8. - Introducir una cantidad de Euros y expresarlas en Pesetas, Liras, Francos,
 Libras, Marcos.
 Un Euro 167pts
 Un Franco 23 pts
 Una Lira 0,07 pts
 Una Libra 345 pts
 Un Marco 85 pts*/

import java.util.Scanner;

public class Ejercicio308 {

    public static void main(String[] args) {
        double euros;
        double pesetas, francos, liras, libras, marcos;
        Scanner lector = new Scanner(System.in);

        System.out.print("Cantidad de euros a convertir: ");
        euros = lector.nextDouble();

        pesetas = euros * 167;
        francos = pesetas / 23;
        liras = pesetas / 0.07;
        libras = pesetas / 345;
        marcos = pesetas / 85;
        System.out.println("\nPesetas: " + pesetas + "\nFrancos: " + francos + "\nLiras: " + liras
                + "\nLibras: " + libras + "\nMarcos :" + marcos);

    }
}
