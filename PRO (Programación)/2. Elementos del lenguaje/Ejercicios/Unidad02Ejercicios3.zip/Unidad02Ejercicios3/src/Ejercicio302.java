/* 2. - Hallar el área y la longitud de una circunferencia, solicitando el radio de la
 misma R .
 Area = PI * R al cuadrado
 Longitud = 2 * PI * R */

import java.util.*;

public class Ejercicio302 {

    public static void main(String[] args) {
        double radio;

        Scanner teclado = new Scanner(System.in);
        System.out.println("Inserte el radio:");
        radio = teclado.nextDouble();
        System.out.println("Area: " + (Math.PI * Math.pow(radio, 2))
                + "\nLongitud: " + (2 * Math.PI * radio));

    }
}
