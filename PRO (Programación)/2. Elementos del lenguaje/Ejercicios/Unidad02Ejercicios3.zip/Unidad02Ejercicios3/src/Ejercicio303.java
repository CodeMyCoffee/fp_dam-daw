/* 3. - Hallar el área de un triángulo.
 Area = (Base * Altura) / 2.*/

import java.util.*;

public class Ejercicio303 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double base, altura;
        
        System.out.println("Inserte la base:");
        base = teclado.nextDouble();
        System.out.println("Inserte la base:");
        altura = teclado.nextDouble();
        System.out.println("Area: " + (base * altura) / 2);

    }
}
