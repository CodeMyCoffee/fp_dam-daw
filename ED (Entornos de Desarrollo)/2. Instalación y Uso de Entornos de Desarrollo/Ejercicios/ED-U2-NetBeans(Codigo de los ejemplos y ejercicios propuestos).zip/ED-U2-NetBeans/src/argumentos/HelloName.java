

package argumentos;

/**
 *
 * @author Imma
 * @company DAM
 * @city  PiK
 */

public class HelloName {
    public static void main(String[] args) {
        String name = args[0];
        System.out.println("Hello " + name);
    }
}
