

package cuenta10;


public class Cuenta10 {

   
    public static void main(String[] args) {
        int cont=1;
        int fin=100;
        System.out.println("Inicio cuenta ");
        while (cont<=fin){
            System.out.println("Contador " + cont );
            cont++;
            }
    }

}
