
package pideNumero;

import javax.swing.JOptionPane;


public class PideNumero2 {

    
 public static void main(String[] args) {
        int num;
        do{
            String texto=JOptionPane.showInputDialog("Introduce un número entre 0 y 10 ");
            num=Integer.parseInt(texto);
        }while(num>=10 || num<0);
        System.out.println("El numero introducido es "+num);
    }
}
