/*mas información : 
 http://chuwiki.chuidiang.org/index.php?title=JOptionPane_y_di%C3%A1logos_modales

 */
package pideNumero;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class PideNumero {

    public static void main(String[] args) {

        int numUsuario;

        String texto = JOptionPane.showInputDialog("Entra un número: ");
        numUsuario = Integer.parseInt(texto);
        JOptionPane.showMessageDialog(null, "El numero introducido es " + texto);
    }
}
