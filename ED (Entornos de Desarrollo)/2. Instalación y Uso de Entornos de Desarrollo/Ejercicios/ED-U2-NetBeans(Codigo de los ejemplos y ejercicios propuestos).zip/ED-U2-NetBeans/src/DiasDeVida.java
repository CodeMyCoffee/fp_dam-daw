
import java.util.Scanner;

/*
 * Dias de Vida
 * 
 */
public class DiasDeVida {

    public static void main(String[] args) {
        Scanner lector = new Scanner(System.in);
        int edad, dias;
        System.out.println("Entra tu edad: ");
        edad = lector.nextInt();
        dias = edad * 360;
        System.out.println("No diré a nadie que tienes " + dias + "  dias!");
    }
}
